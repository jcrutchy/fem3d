@echo off
setlocal
cd /d "%~dp0"
if "%FPC%"=="" set FPC=fpc

echo Building FEM3D CLI...
%FPC% -O3 -Fu"src" -Fu"solver\common" -Fu"tests" "cli\FEM3D_CLI.lpr" -o"FEM3D_CLI.exe"
if errorlevel 1 exit /b %errorlevel%

echo Building linear-static solver...
%FPC% -O3 -Fu"src" -Fu"solver\common" "solver\FEM3D_LinStatic.lpr" -o"FEM3D_LinStatic.exe"
if errorlevel 1 exit /b %errorlevel%

echo Building core verification...
%FPC% -O3 -Fu"src" "tests\verify.lpr" -o"verify.exe"
if errorlevel 1 exit /b %errorlevel%

echo Building headless contract verification...
%FPC% -O3 -Fu"src" "tests\HeadlessContract.lpr" -o"HeadlessContract.exe"
if errorlevel 1 exit /b %errorlevel%

echo.
echo Build completed.
