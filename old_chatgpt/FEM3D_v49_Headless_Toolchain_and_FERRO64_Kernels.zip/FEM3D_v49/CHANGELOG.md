# v0.49
- Shifted development priority toward the headless CLI/solver/result toolchain.
- Added strict model-header checking to the native model reader.
- Fixed analysis-case type loading so changing `Type=` preserves the concrete analysis settings defaults.
- Added `FEMFastMath.pas` with conservative four-way-unrolled numerical kernels; LDL^T factorisation uses the weighted dot-product kernel.
- Added richer result metadata parsing including solver provenance and failure message.
- Added `FEM3D_CLI verify`.
- Added result-file existence checking to the CLI solve path.
- Refactored the linear-static solver to use the shared solver contract constants and structured cleanup rather than terminating from nested solver blocks.
- Added `tests/HeadlessContract.lpr`.
- Added `build_headless.bat` and `smoke_headless.bat`.
- Reviewed the supplied FERRO64 library and documented the selected ideas and intentionally deferred AVX2/sparse integrations.

# Changelog

## v0.48

- Restored/retained Lazarus `.lfm` resources from v0.47.
- Corrected native model analysis-case loading so `Name`, `Type`, `LoadCase` and `ResultID` are actually persisted/restored.
- Added support for `[SETTINGS]` analysis sections during model loading.
- Accepted `LINEAR_STATIC` / `LINEAR-STATIC` style analysis type spellings.
- Accepted `ReferenceDenseLDLT` as an alias for the reference dense LDL^T solver name.
- Added `Tolerance=` compatibility for linear-static model files.
- Removed duplicate inactive solver source tree under `solver/src`.
- Added GUI-independent `FEM3D_CLI.exe` orchestration client.
- Added headless `validate`, `info`, `results` and `solve` commands.
- Added headless workflow documentation.
