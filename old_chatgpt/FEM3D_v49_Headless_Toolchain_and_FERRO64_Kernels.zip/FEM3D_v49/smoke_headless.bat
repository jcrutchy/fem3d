@echo off
setlocal
cd /d "%~dp0"

if not exist "FEM3D_CLI.exe" call build_headless.bat
if errorlevel 1 exit /b %errorlevel%

echo === Core verification ===
verify.exe
if errorlevel 1 exit /b %errorlevel%

echo.
echo === Headless model contract ===
HeadlessContract.exe
if errorlevel 1 exit /b %errorlevel%

echo.
echo === CLI validation ===
FEM3D_CLI.exe validate "examples\headless_cantilever.fem3d"
if errorlevel 1 exit /b %errorlevel%

echo.
echo === CLI solve ===
FEM3D_CLI.exe solve "examples\headless_cantilever.fem3d"
if errorlevel 1 exit /b %errorlevel%

echo.
echo === Result inspection ===
FEM3D_CLI.exe results "examples\headless_cantilever.fem3dres"
if errorlevel 1 exit /b %errorlevel%

echo.
echo HEADLESS TOOLCHAIN SMOKE TEST PASSED
