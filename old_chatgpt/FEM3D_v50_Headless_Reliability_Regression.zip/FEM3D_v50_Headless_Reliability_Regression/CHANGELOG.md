# FEM3D changelog

## v0.50 — CLI reliability and verified regression corpus

- Added external end-to-end `FEM3D_TestRunner.exe`.
- Added manually verified linear-static beam corpus.
- Added invalid-input regression corpus.
- Added frozen corpus fingerprints with explicit re-freeze workflow.
- Added five hand-calculable beam benchmark sets:
  - cantilever tip Z load;
  - cantilever axial load;
  - cantilever tip Y load;
  - cantilever end moment;
  - simply supported two-element centre-load beam.
- Fixed CLI command-dispatch argument-count bug that made `verify` unreachable.
- Added ten-minute solver process timeout and process-start exception handling.
- Added `regression_headless.bat` and `freeze_verified.bat`.
- Expanded headless smoke test to include the end-to-end regression corpus.
