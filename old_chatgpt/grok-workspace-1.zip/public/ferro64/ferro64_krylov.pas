{ Iterative solvers for huge SPD / general sparse systems:
  CG, Jacobi-PCG, IC(0)-PCG, GMRES(m), BiCGSTAB. }
unit ferro64_krylov;

{$mode objfpc}{$H+}

interface

uses
  ferro64_types, ferro64_sparse;

type
  TPrecondKind = (pkNone, pkJacobi, pkIC0);

function CgSolve(const A: TSpMat; const b: TVec; var x: TVec;
  tol: Double; maxIter: Integer; out info: TIterInfo): Boolean;

function PcgSolve(const A: TSpMat; const b: TVec; var x: TVec;
  kind: TPrecondKind; tol: Double; maxIter: Integer;
  out info: TIterInfo): Boolean;

function GmresSolve(const A: TSpMat; const b: TVec; var x: TVec;
  restart: Integer; tol: Double; maxIter: Integer;
  out info: TIterInfo): Boolean;

function BicgstabSolve(const A: TSpMat; const b: TVec; var x: TVec;
  tol: Double; maxIter: Integer; out info: TIterInfo): Boolean;

implementation

uses
  Math, ferro64_vec;

type
  TIC0 = record
    n: TIndex;
    rowPtr, colInd: PIndex;
    val: PDouble;
    ok: Boolean;
  end;

function FindVal(rowPtr, colInd: PIndex; val: PDouble; i, j: TIndex;
  out p: TIndex): Boolean;
var
  k: TIndex;
begin
  for k := rowPtr[i] to rowPtr[i + 1] - 1 do
    if colInd[k] = j then
    begin
      p := k;
      Exit(True);
    end;
  p := -1;
  Result := False;
end;

procedure BuildIC0(const A: TSpMat; out M: TIC0);
{ Incomplete Cholesky with zero fill, Saad-style:
  for each existing (i,j) i>=j: L_ij := (A_ij - sum_k L_ik L_jk) / L_jj
  L_ii := sqrt(...). Pattern copied from A. }
var
  i, j, p, q, r, k, pj: TIndex;
  s, Lii: Double;
  n: TIndex;
begin
  n := A.rows;
  M.n := n;
  M.ok := True;
  M.rowPtr := PIndex(FerroAlloc((n + 1) * SizeOf(TIndex)));
  M.colInd := PIndex(FerroAlloc(A.nnz * SizeOf(TIndex)));
  M.val := PDouble(FerroAlloc(A.nnz * SizeOf(Double)));
  FerroCopyBytes(M.rowPtr, A.rowPtr, (n + 1) * SizeOf(TIndex));
  FerroCopyBytes(M.colInd, A.colInd, A.nnz * SizeOf(TIndex));
  FerroCopyBytes(M.val, A.val, A.nnz * SizeOf(Double));

  for i := 0 to n - 1 do
  begin
    for p := M.rowPtr[i] to M.rowPtr[i + 1] - 1 do
    begin
      j := M.colInd[p];
      if j > i then Continue;
      s := M.val[p];
      for q := M.rowPtr[i] to M.rowPtr[i + 1] - 1 do
      begin
        k := M.colInd[q];
        if (k >= j) or (k >= i) then Continue;
        if FindVal(M.rowPtr, M.colInd, M.val, j, k, pj) then
          s := s - M.val[q] * M.val[pj];
      end;
      if j < i then
      begin
        if not FindVal(M.rowPtr, M.colInd, M.val, j, j, r) then
        begin
          M.ok := False;
          Exit;
        end;
        Lii := M.val[r];
        if Abs(Lii) < FERRO_EPS then
        begin
          M.ok := False;
          Exit;
        end;
        M.val[p] := s / Lii;
      end
      else
      begin
        if s <= 0 then
        begin
          M.ok := False;
          Exit;
        end;
        M.val[p] := Sqrt(s);
      end;
    end;
  end;
end;

procedure IC0Free(var M: TIC0);
begin
  FerroFree(M.rowPtr);
  FerroFree(M.colInd);
  FerroFree(M.val);
  M.rowPtr := nil;
  M.colInd := nil;
  M.val := nil;
  M.ok := False;
end;

procedure IC0Apply(const M: TIC0; const r: TVec; var z: TVec);
var
  i, p, n: TIndex;
  s, diag: Double;
  y: TVec;
begin
  n := M.n;
  y := VecMake(n);
  { L y = r }
  for i := 0 to n - 1 do
  begin
    s := r.data[i];
    diag := 1.0;
    for p := M.rowPtr[i] to M.rowPtr[i + 1] - 1 do
      if M.colInd[p] < i then
        s := s - M.val[p] * y.data[M.colInd[p]]
      else if M.colInd[p] = i then
        diag := M.val[p];
    if Abs(diag) < FERRO_EPS then diag := 1.0;
    y.data[i] := s / diag;
  end;
  { L^T z = y  (L^T has entries L_ji in row j, col i with j > i) }
  KernelCopy(n, y.data, z.data);
  for i := n - 1 downto 0 do
  begin
    diag := 1.0;
    for p := M.rowPtr[i] to M.rowPtr[i + 1] - 1 do
      if M.colInd[p] = i then
        diag := M.val[p];
    if Abs(diag) < FERRO_EPS then diag := 1.0;
    z.data[i] := z.data[i] / diag;
    for p := M.rowPtr[i] to M.rowPtr[i + 1] - 1 do
      if M.colInd[p] < i then
        z.data[M.colInd[p]] := z.data[M.colInd[p]] - M.val[p] * z.data[i];
  end;
  VecFree(y);
end;

procedure JacobiApply(const d, r: TVec; var z: TVec);
var
  i: TIndex;
begin
  for i := 0 to d.n - 1 do
    if Abs(d.data[i]) > FERRO_EPS then
      z.data[i] := r.data[i] / d.data[i]
    else
      z.data[i] := r.data[i];
end;

function CgSolve(const A: TSpMat; const b: TVec; var x: TVec;
  tol: Double; maxIter: Integer; out info: TIterInfo): Boolean;
begin
  Result := PcgSolve(A, b, x, pkNone, tol, maxIter, info);
end;

function PcgSolve(const A: TSpMat; const b: TVec; var x: TVec;
  kind: TPrecondKind; tol: Double; maxIter: Integer;
  out info: TIterInfo): Boolean;
var
  r, p, Ap, z, d: TVec;
  rz, rzOld, rz0, alpha, beta, bnrm, rnrm: Double;
  it: Integer;
  t0: QWord;
  M: TIC0;
begin
  FillChar(info, SizeOf(info), 0);
  FillChar(M, SizeOf(M), 0);
  t0 := GetTickCount64;
  r := VecMake(b.n);
  p := VecMake(b.n);
  Ap := VecMake(b.n);
  z := VecMake(b.n);
  d := VecMake(b.n);
  if kind = pkJacobi then SpDiag(A, d);
  if kind = pkIC0 then BuildIC0(A, M);

  SpResidual(A, x, b, r);
  bnrm := VecNrm2(b);
  if bnrm = 0 then bnrm := 1.0;

  case kind of
    pkJacobi: JacobiApply(d, r, z);
    pkIC0:
      if M.ok then IC0Apply(M, r, z) else VecCopy(r, z);
  else
    VecCopy(r, z);
  end;
  VecCopy(z, p);
  rz := VecDot(r, z);
  rz0 := rz;

  Result := False;
  it := 0;
  while it < maxIter do
  begin
    rnrm := VecNrm2(r);
    info.residual := rnrm / bnrm;
    if info.residual <= tol then
    begin
      Result := True;
      Break;
    end;
    Inc(it);
    SpMV(A, p, Ap);
    alpha := VecDot(p, Ap);
    if Abs(alpha) < FERRO_EPS * (Abs(rz0) + 1.0) then Break;
    alpha := rz / alpha;
    VecAxpy(alpha, p, x);
    VecAxpy(-alpha, Ap, r);
    case kind of
      pkJacobi: JacobiApply(d, r, z);
      pkIC0:
        if M.ok then IC0Apply(M, r, z) else VecCopy(r, z);
    else
      VecCopy(r, z);
    end;
    rzOld := rz;
    rz := VecDot(r, z);
    if Abs(rzOld) < FERRO_EPS * (Abs(rz0) + 1.0) then Break;
    beta := rz / rzOld;
    KernelScale(p.n, beta, p.data);
    KernelAxpy(p.n, 1.0, z.data, p.data);
  end;
  info.iters := it;
  info.residual := VecNrm2(r) / bnrm;
  info.converged := Result;
  info.elapsedMs := GetTickCount64 - t0;
  VecFree(r); VecFree(p); VecFree(Ap); VecFree(z); VecFree(d);
  if kind = pkIC0 then IC0Free(M);
end;

function GmresSolve(const A: TSpMat; const b: TVec; var x: TVec;
  restart: Integer; tol: Double; maxIter: Integer;
  out info: TIterInfo): Boolean;
var
  n, m, i, j, k, it, jend: TIndex;
  V: TMat;
  H: array of array of Double;
  cs, sn, g, y: array of Double;
  w, resid: TVec;
  bnrm, rnrm, hii, hij, tmp: Double;
  t0: QWord;
  done: Boolean;
begin
  FillChar(info, SizeOf(info), 0);
  t0 := GetTickCount64;
  n := b.n;
  if restart < 4 then restart := 4;
  if restart > 50 then restart := 50;
  m := restart;
  V := MatMake(n, m + 1);
  SetLength(H, m + 1, m);
  SetLength(cs, m);
  SetLength(sn, m);
  SetLength(g, m + 1);
  SetLength(y, m);
  w := VecMake(n);
  resid := VecMake(n);
  bnrm := VecNrm2(b);
  if bnrm = 0 then bnrm := 1.0;
  Result := False;
  it := 0;
  done := False;

  while (it < maxIter) and (not done) do
  begin
    SpResidual(A, x, b, resid);
    rnrm := VecNrm2(resid);
    info.residual := rnrm / bnrm;
    if info.residual <= tol then
    begin
      Result := True;
      Break;
    end;
    KernelScale(n, 1.0 / rnrm, resid.data);
    KernelCopy(n, resid.data, MatCol(V, 0));
    for i := 0 to m do g[i] := 0;
    g[0] := rnrm;
    jend := -1;

    for j := 0 to m - 1 do
    begin
      Inc(it);
      KernelCopy(n, MatCol(V, j), w.data);
      SpMV(A, w, w);
      for i := 0 to j do
      begin
        H[i, j] := KernelDot(n, MatCol(V, i), w.data);
        KernelAxpy(n, -H[i, j], MatCol(V, i), w.data);
      end;
      H[j + 1, j] := KernelNrm2(n, w.data);
      if H[j + 1, j] > FERRO_EPS then
      begin
        KernelScale(n, 1.0 / H[j + 1, j], w.data);
        KernelCopy(n, w.data, MatCol(V, j + 1));
      end;
      for i := 0 to j - 1 do
      begin
        tmp := cs[i] * H[i, j] + sn[i] * H[i + 1, j];
        H[i + 1, j] := -sn[i] * H[i, j] + cs[i] * H[i + 1, j];
        H[i, j] := tmp;
      end;
      hii := H[j, j];
      hij := H[j + 1, j];
      tmp := Sqrt(hii * hii + hij * hij);
      if tmp = 0 then tmp := FERRO_EPS;
      cs[j] := hii / tmp;
      sn[j] := hij / tmp;
      H[j, j] := tmp;
      H[j + 1, j] := 0;
      tmp := cs[j] * g[j];
      g[j + 1] := -sn[j] * g[j];
      g[j] := tmp;
      info.residual := Abs(g[j + 1]) / bnrm;
      jend := j;
      if (info.residual <= tol) or (it >= maxIter) then
        Break;
    end;

    if jend < 0 then Break;
    for i := 0 to jend do y[i] := g[i];
    for i := jend downto 0 do
    begin
      for k := i + 1 to jend do
        y[i] := y[i] - H[i, k] * y[k];
      if Abs(H[i, i]) < FERRO_EPS then
        y[i] := 0
      else
        y[i] := y[i] / H[i, i];
    end;
    for i := 0 to jend do
      KernelAxpy(n, y[i], MatCol(V, i), x.data);
    if info.residual <= tol then
    begin
      Result := True;
      done := True;
    end;
  end;

  info.iters := Integer(it);
  info.converged := Result;
  info.elapsedMs := GetTickCount64 - t0;
  MatFree(V);
  VecFree(w);
  VecFree(resid);
end;

function BicgstabSolve(const A: TSpMat; const b: TVec; var x: TVec;
  tol: Double; maxIter: Integer; out info: TIterInfo): Boolean;
var
  r, rhat, p, v, s, t: TVec;
  rho, rhoOld, alpha, omega, beta, bnrm, rnrm: Double;
  it: Integer;
  t0: QWord;
begin
  FillChar(info, SizeOf(info), 0);
  t0 := GetTickCount64;
  r := VecMake(b.n);
  rhat := VecMake(b.n);
  p := VecMake(b.n);
  v := VecMake(b.n);
  s := VecMake(b.n);
  t := VecMake(b.n);
  SpResidual(A, x, b, r);
  VecCopy(r, rhat);
  VecCopy(r, p);
  rho := VecDot(rhat, r);
  bnrm := VecNrm2(b);
  if bnrm = 0 then bnrm := 1.0;
  Result := False;
  omega := 1.0;
  alpha := 1.0;
  it := 0;
  while it < maxIter do
  begin
    rnrm := VecNrm2(r);
    info.residual := rnrm / bnrm;
    if info.residual <= tol then
    begin
      Result := True;
      Break;
    end;
    Inc(it);
    SpMV(A, p, v);
    alpha := VecDot(rhat, v);
    if Abs(alpha) < FERRO_EPS then Break;
    alpha := rho / alpha;
    VecCopy(r, s);
    VecAxpy(-alpha, v, s);
    if VecNrm2(s) / bnrm <= tol then
    begin
      VecAxpy(alpha, p, x);
      info.residual := VecNrm2(s) / bnrm;
      Result := True;
      Break;
    end;
    SpMV(A, s, t);
    omega := VecDot(t, t);
    if Abs(omega) < FERRO_EPS then Break;
    omega := VecDot(t, s) / omega;
    VecAxpy(alpha, p, x);
    VecAxpy(omega, s, x);
    VecCopy(s, r);
    VecAxpy(-omega, t, r);
    rhoOld := rho;
    rho := VecDot(rhat, r);
    if Abs(rhoOld * omega) < FERRO_EPS then Break;
    beta := (rho / rhoOld) * (alpha / omega);
    VecAxpy(-omega, v, p);
    KernelScale(p.n, beta, p.data);
    KernelAxpy(p.n, 1.0, r.data, p.data);
  end;
  info.iters := it;
  info.residual := VecNrm2(r) / bnrm;
  info.converged := Result;
  info.elapsedMs := GetTickCount64 - t0;
  VecFree(r); VecFree(rhat); VecFree(p); VecFree(v); VecFree(s); VecFree(t);
end;

end.
