{ FERRO 1.0 — zero-dependency double-precision linear algebra for FEA.
  Uses every unit in the library so a single `ferro64` in your uses-clause
  is enough.

  Compile (Linux x86_64, AVX2):
    fpc -O3 -CpCOREAVX2 -CfAVX2 -OpCOREAVX2 -Fu. examples/bench.lpr

  Layout is column-major, 0-based, 32-byte aligned. No objects, no RTTI
  required, no third-party units. }
unit ferro64;

{$mode objfpc}{$H+}

interface

uses
  ferro64_types,
  ferro64_cpu,
  ferro64_vec,
  ferro64_mat,
  ferro64_decomp,
  ferro64_sparse,
  ferro64_krylov,
  ferro64_skyline,
  ferro64_direct,
  ferro64_fea;

function FerroBanner: string;

implementation

function FerroBanner: string;
begin
  Result := 'FERRO ' + FERRO_VERSION + '  kernel=' + CpuKernelName +
    '  ' + CpuCaps.brand;
end;

end.
