# FERRO

Zero-dependency **double-precision** linear algebra for finite-element analysis,
written in FreePascal. Procedural. Record types. Intel AVX2+FMA inline assembly
on x86_64; blocked Pascal everywhere else.

Column-major, 0-based, 32-byte aligned. MATLAB/BLAS layout so a stiffness
matrix looks the way you think it does.

```
fpc -O3 -CpCOREAVX2 -CfAVX2 -OpCOREAVX2 -Fu. examples/bench.lpr
fpc -O3 -Fu. -Fu.. tests/selftest.lpr
fpc -O3 -Fu. examples/cantilever.lpr
```

Windows: the same units, the same `{$IFDEF WIN64}` kernels (RCX/RDX/R8/R9 + XMM).

## Units

| Unit | What it is |
|---|---|
| `ferro64_types` | `TVec`, `TMat`, `TSpMat`, `TSkyline`, `TTriplets`, aligned alloc |
| `ferro64_cpu` | CPUID + XGETBV, AVX2/FMA dispatch |
| `ferro64_vec` | DOT, AXPY, SCALE, NRM2, COPY — 8-wide FMA kernels |
| `ferro64_mat` | GEMV, GER, blocked GEMM around an 8×4 AVX2 microkernel |
| `ferro64_decomp` | Cholesky, LU (partial pivot), Householder QR |
| `ferro64_sparse` | triplets → CSR, SpMV, RCM ordering |
| `ferro64_skyline` | profile Cholesky — the FEA classic |
| `ferro64_krylov` | CG, Jacobi/IC(0) PCG, GMRES(m), BiCGSTAB |
| `ferro64_direct` | RCM → skyline SPD solve |
| `ferro64_fea` | CST plane-stress assembly, Dirichlet, von Mises |
| `ferro64` | umbrella unit |

No objects. No third-party units. No heap besides the aligned allocator.

## Kernels

Hot loops live in `ferro64_vec.pas` and `ferro64_mat.pas` under
`{$ASMMODE INTEL}`. The GEMM 8×4 kernel keeps eight YMM accumulators live,
broadcasts B, and `vfmadd231pd`s A panels. `vzeroupper` on the way out so
you can mix with Pascal/SSE.

SpMV stays scalar-inner: AVX2 gathers lose to a tight CSR loop on FEA
sparsity.

## Solving a cantilever

```pascal
mesh := MeshRect(24, 8, 10.0, 2.0, 210e9, 0.3, 0.1);
sys  := SysFromMesh(mesh);
AssembleLoadTip(mesh, -1e4, sys.f);
FixEdgeX0(mesh, sys);
ApplyDirichlet(sys);
u := VecMake(sys.ndof);
PcgSolve(sys.K, sys.f, u, pkJacobi, 1e-10, 4000, info);
{ or } SpCholSolve(sys.K, sys.f, u, True);
```

For banded 2-D meshes, skyline Cholesky after RCM is usually the fastest
correct answer. For 3-D / huge N, PCG with Jacobi or IC(0) stays in RAM.

## Types

```pascal
TVec = record n: NativeInt; data: PDouble; owned: Boolean; end;
TMat = record rows, cols, ld: NativeInt; data: PDouble; owned: Boolean; end;
{ A(i,j) = data[i + j*ld] }
TSpMat = record rows, cols, nnz: NativeInt;
         rowPtr, colInd: PNativeInt; val: PDouble; owned: Boolean; end;
```

Views (`VecView` / `MatView`) never free. Owned records do.

MIT license. No dependencies, no exceptions in the kernels besides OOM.
