{ CPUID / XGETBV feature detection. AVX2+FMA is the fast path;
  everything else falls back to blocked Pascal. }
unit ferro64_cpu;

{$mode objfpc}{$H+}
{$IFDEF CPUX86_64}
{$ASMMODE INTEL}
{$ENDIF}

interface

type
  TCpuCaps = record
    avx:  Boolean;
    avx2: Boolean;
    fma:  Boolean;
    vendor: string;
    brand:  string;
  end;

function CpuCaps: TCpuCaps;
function CpuHasAVX2FMA: Boolean;
function CpuKernelName: string;

implementation

var
  GCaps: TCpuCaps;
  GInit: Boolean = False;

{$IFDEF CPUX86_64}
procedure CpuidLeaf(leaf, subleaf: LongWord; var eax, ebx, ecx, edx: LongWord);
  assembler; nostackframe;
asm
{$IFDEF WIN64}
  mov     r10, r8            { &eax }
  mov     r11, r9            { &ebx }
  mov     eax, ecx           { leaf }
  mov     ecx, edx           { subleaf }
  push    rbx
  cpuid
  mov     dword ptr [r10], eax
  mov     dword ptr [r11], ebx
  mov     r10, [rsp+48]      { &ecx  5th arg — fragile; use alternate }
  pop     rbx
{$ELSE}
  { SysV: rdi=leaf, rsi=subleaf, rdx=&eax, rcx=&ebx, r8=&ecx, r9=&edx }
  mov     r10, rdx
  mov     r11, rcx
  mov     eax, edi
  mov     ecx, esi
  push    rbx
  cpuid
  mov     dword ptr [r10], eax
  mov     dword ptr [r11], ebx
  mov     dword ptr [r8],  ecx
  mov     dword ptr [r9],  edx
  pop     rbx
{$ENDIF}
end;

{ Portable CPUID via FPC's built-in when the Win64 5-arg path is awkward. }
procedure CpuidRaw(leaf, subleaf: LongWord; out a, b, c, d: LongWord);
begin
{$IFDEF WIN64}
  asm
    mov     eax, leaf
    mov     ecx, subleaf
    push    rbx
    cpuid
    mov     a, eax
    mov     b, ebx
    mov     c, ecx
    mov     d, edx
    pop     rbx
  end;
{$ELSE}
  CpuidLeaf(leaf, subleaf, a, b, c, d);
{$ENDIF}
end;

function Xgetbv0: QWord; assembler; nostackframe;
asm
  xor     ecx, ecx
  xgetbv                       { edx:eax }
  shl     rdx, 32
  or      rax, rdx
end;
{$ENDIF}

procedure Detect;
{$IFDEF CPUX86_64}
var
  a, b, c, d: LongWord;
  i: Integer;
  buf: array[0..47] of AnsiChar;
  xcr: QWord;
{$ENDIF}
begin
  GCaps.avx := False;
  GCaps.avx2 := False;
  GCaps.fma := False;
  GCaps.vendor := 'unknown';
  GCaps.brand := 'unknown';
{$IFDEF CPUX86_64}
  CpuidRaw(0, 0, a, b, c, d);
  FillChar(buf, SizeOf(buf), 0);
  Move(b, buf[0], 4);
  Move(d, buf[4], 4);
  Move(c, buf[8], 4);
  GCaps.vendor := string(PAnsiChar(@buf[0]));

  CpuidRaw(1, 0, a, b, c, d);
  { OSXSAVE = ecx bit 27, AVX = bit 28, FMA = bit 12 }
  if ((c and (1 shl 27)) <> 0) and ((c and (1 shl 28)) <> 0) then
  begin
    xcr := Xgetbv0;
    if (xcr and 6) = 6 then
    begin
      GCaps.avx := True;
      GCaps.fma := (c and (1 shl 12)) <> 0;
      CpuidRaw(7, 0, a, b, c, d);
      GCaps.avx2 := (b and (1 shl 5)) <> 0;
    end;
  end;

  FillChar(buf, SizeOf(buf), 0);
  for i := 0 to 2 do
  begin
    CpuidRaw($80000002 + LongWord(i), 0, a, b, c, d);
    Move(a, buf[i * 16 + 0], 4);
    Move(b, buf[i * 16 + 4], 4);
    Move(c, buf[i * 16 + 8], 4);
    Move(d, buf[i * 16 + 12], 4);
  end;
  GCaps.brand := Trim(string(PAnsiChar(@buf[0])));
{$ELSE}
  GCaps.vendor := 'non-x86_64';
  GCaps.brand := 'pascal-fallback';
{$ENDIF}
  GInit := True;
end;

function CpuCaps: TCpuCaps;
begin
  if not GInit then Detect;
  Result := GCaps;
end;

function CpuHasAVX2FMA: Boolean;
begin
  if not GInit then Detect;
  Result := GCaps.avx2 and GCaps.fma;
end;

function CpuKernelName: string;
begin
  if not GInit then Detect;
  if GCaps.avx2 and GCaps.fma then
    Result := 'avx2+fma'
  else if GCaps.avx then
    Result := 'avx'
  else
    Result := 'scalar';
end;

end.
