program bench;
{$mode objfpc}{$H+}
uses
  SysUtils, ferro64;

var
  n, k, it, i: NativeInt;
  A, B, C: TMat;
  x, y: TVec;
  t0, t1: QWord;
  flops, gflops: Double;
begin
  WriteLn(FerroBanner);
  n := 256;
  if ParamCount >= 1 then n := StrToIntDef(ParamStr(1), n);
  WriteLn('GEMM n=', n);
  A := MatMake(n, n);
  B := MatMake(n, n);
  C := MatMake(n, n);
  for i := 0 to n * n - 1 do
  begin
    A.data[i] := ((i * 1103515245 + 12345) and $7fffffff) / 2147483647.0;
    B.data[i] := ((i * 214013 + 2531011) and $7fffffff) / 2147483647.0;
  end;
  MatGemm(moNoTrans, moNoTrans, 1.0, A, B, 0.0, C); { warmup }
  t0 := GetTickCount64;
  it := 0;
  repeat
    MatGemm(moNoTrans, moNoTrans, 1.0, A, B, 0.0, C);
    Inc(it);
    t1 := GetTickCount64;
  until t1 - t0 >= 400;
  flops := 2.0 * n * n * n * it;
  gflops := flops / ((t1 - t0) * 1.0e6);
  WriteLn(Format('  %d iters in %d ms   %.2f GFLOP/s  C(0,0)=%.6f',
    [it, t1 - t0, gflops, C.data[0]]));
  x := VecMake(n);
  y := VecMake(n);
  VecFill(x, 1.0);
  t0 := GetTickCount64;
  for i := 1 to 400 do
    MatGemv(moNoTrans, 1.0, A, x, 0.0, y);
  t1 := GetTickCount64;
  WriteLn(Format('GEMV 400 iters %d ms  nrm2=%.6f', [t1 - t0, VecNrm2(y)]));
  MatFree(A); MatFree(B); MatFree(C);
  VecFree(x); VecFree(y);
end.
