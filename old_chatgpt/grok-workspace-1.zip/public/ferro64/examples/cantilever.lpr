program cantilever;
{ 2-D plane-stress cantilever. Tip load, left edge fixed.
  Compare tip deflection against Euler-Bernoulli PL^3 / (3EI). }
{$mode objfpc}{$H+}
uses
  SysUtils, Math, ferro64;

var
  mesh: TFeaMesh2;
  sys: TFeaSystem;
  u: TVec;
  info: TIterInfo;
  nx, ny, i, tip: NativeInt;
  Lx, Ly, E, nu, t, P, Izz, analytical, num, vmmax: Double;
  vm: PDouble;
  ok: Boolean;
begin
  nx := 24; ny := 8;
  Lx := 10.0; Ly := 2.0;
  E := 210e9; nu := 0.3; t := 0.1;
  P := -1.0e4;
  mesh := MeshRect(nx, ny, Lx, Ly, E, nu, t);
  sys := SysFromMesh(mesh);
  AssembleLoadTip(mesh, P, sys.f);
  FixEdgeX0(mesh, sys);
  ApplyDirichlet(sys);
  u := VecMake(sys.ndof);
  WriteLn(FerroBanner);
  WriteLn(Format('mesh %dx%d  nodes=%d  dof=%d  nnz=%d',
    [nx, ny, mesh.nnode, sys.ndof, sys.K.nnz]));
  ok := PcgSolve(sys.K, sys.f, u, pkJacobi, 1e-10, 4000, info);
  WriteLn(Format('PCG-Jacobi  iters=%d  relres=%.3e  %.1f ms  ok=%s',
    [info.iters, info.residual, info.elapsedMs, BoolToStr(ok, True)]));
  { max |uy| on the tip }
  num := 0;
  for i := 0 to mesh.nnode - 1 do
    if mesh.node[i].x >= Lx - 1e-12 then
      if Abs(u.data[2 * i + 1]) > Abs(num) then
      begin
        num := u.data[2 * i + 1];
        tip := i;
      end;
  Izz := t * Ly * Ly * Ly / 12.0;
  analytical := P * Lx * Lx * Lx / (3.0 * E * Izz);
  WriteLn(Format('tip uy  numeric=%.6e  beam=%.6e  ratio=%.4f  node=%d',
    [num, analytical, num / analytical, tip]));
  vm := PDouble(FerroAlloc(mesh.ntri * SizeOf(Double)));
  RecoverVonMises(mesh, u, vm);
  vmmax := 0;
  for i := 0 to mesh.ntri - 1 do
    if vm[i] > vmmax then vmmax := vm[i];
  WriteLn(Format('max von Mises = %.6e Pa', [vmmax]));
  FerroFree(vm);
  VecFree(u);
  SysFree(sys);
  MeshFree(mesh);
end.
