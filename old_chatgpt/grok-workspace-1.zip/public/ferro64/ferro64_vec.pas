{ Level-1 BLAS. AVX2+FMA kernels for dot, axpy, scale, nrm2, copy, amax. }
unit ferro64_vec;

{$mode objfpc}{$H+}
{$IFDEF CPUX86_64}
{$ASMMODE INTEL}
{$ENDIF}

interface

uses
  ferro64_types;

procedure VecCopy(const x: TVec; var y: TVec);
procedure VecScale(alpha: Double; var x: TVec);
procedure VecAxpy(alpha: Double; const x: TVec; var y: TVec);
function  VecDot(const x, y: TVec): Double;
function  VecNrm2(const x: TVec): Double;
function  VecAsum(const x: TVec): Double;
function  VecAmax(const x: TVec): Double;
procedure VecHadamard(const x: TVec; var y: TVec);
procedure VecWAXPBY(alpha: Double; const x: TVec; beta: Double; const y: TVec; var w: TVec);

{ Raw pointer kernels — used by GEMM / sparse inner loops. }
procedure KernelCopy(n: TIndex; src, dst: PDouble);
procedure KernelScale(n: TIndex; alpha: Double; x: PDouble);
procedure KernelAxpy(n: TIndex; alpha: Double; x, y: PDouble);
function  KernelDot(n: TIndex; x, y: PDouble): Double;
function  KernelNrm2(n: TIndex; x: PDouble): Double;

implementation

uses
  Math, ferro64_cpu;

procedure KernelCopy_Pas(n: TIndex; src, dst: PDouble);
begin
  FerroCopyBytes(dst, src, n * SizeOf(Double));
end;

procedure KernelScale_Pas(n: TIndex; alpha: Double; x: PDouble);
var
  i: TIndex;
begin
  if alpha = 0.0 then
    FerroZero(x, n * SizeOf(Double))
  else if alpha <> 1.0 then
    for i := 0 to n - 1 do
      x[i] := x[i] * alpha;
end;

procedure KernelAxpy_Pas(n: TIndex; alpha: Double; x, y: PDouble);
var
  i: TIndex;
begin
  if alpha = 0.0 then Exit;
  i := 0;
  while i <= n - 4 do
  begin
    y[i    ] := y[i    ] + alpha * x[i    ];
    y[i + 1] := y[i + 1] + alpha * x[i + 1];
    y[i + 2] := y[i + 2] + alpha * x[i + 2];
    y[i + 3] := y[i + 3] + alpha * x[i + 3];
    Inc(i, 4);
  end;
  while i < n do
  begin
    y[i] := y[i] + alpha * x[i];
    Inc(i);
  end;
end;

function KernelDot_Pas(n: TIndex; x, y: PDouble): Double;
var
  i: TIndex;
  s0, s1, s2, s3: Double;
begin
  s0 := 0; s1 := 0; s2 := 0; s3 := 0;
  i := 0;
  while i <= n - 4 do
  begin
    s0 := s0 + x[i    ] * y[i    ];
    s1 := s1 + x[i + 1] * y[i + 1];
    s2 := s2 + x[i + 2] * y[i + 2];
    s3 := s3 + x[i + 3] * y[i + 3];
    Inc(i, 4);
  end;
  Result := s0 + s1 + s2 + s3;
  while i < n do
  begin
    Result := Result + x[i] * y[i];
    Inc(i);
  end;
end;

function KernelNrm2_Pas(n: TIndex; x: PDouble): Double;
begin
  Result := Sqrt(KernelDot_Pas(n, x, x));
end;

{$IFDEF CPUX86_64}

{ VecDot: 8-wide FMA, two independent accumulators to hide latency.
  SysV  n=rdi  x=rsi  y=rdx
  Win64 n=rcx  x=rdx  y=r8 }
function DotAVX2(n: TIndex; x, y: PDouble): Double; assembler; nostackframe;
asm
{$IFDEF WIN64}
  mov     r9,  rcx
  mov     r10, rdx
  mov     r11, r8
{$ELSE}
  mov     r9,  rdi
  mov     r10, rsi
  mov     r11, rdx
{$ENDIF}
  vxorpd  ymm0, ymm0, ymm0
  vxorpd  ymm1, ymm1, ymm1
  test    r9, r9
  jle     @@done
  mov     rax, r9
  shr     rax, 3
  jz      @@tail
  align   16
@@loop:
  vmovupd ymm2, ymmword ptr [r10]
  vmovupd ymm3, ymmword ptr [r10 + 32]
  vfmadd231pd ymm0, ymm2, ymmword ptr [r11]
  vfmadd231pd ymm1, ymm3, ymmword ptr [r11 + 32]
  add     r10, 64
  add     r11, 64
  dec     rax
  jnz     @@loop
@@tail:
  and     r9, 7
  jz      @@hsum
@@tloop:
  vmovsd  xmm2, qword ptr [r10]
  vmulsd  xmm2, xmm2, qword ptr [r11]
  vaddsd  xmm0, xmm0, xmm2
  add     r10, 8
  add     r11, 8
  dec     r9
  jnz     @@tloop
@@hsum:
  vaddpd  ymm0, ymm0, ymm1
  vextractf128 xmm1, ymm0, 1
  vaddpd  xmm0, xmm0, xmm1
  vhaddpd xmm0, xmm0, xmm0
@@done:
  vzeroupper
end;

{ y += alpha * x
  SysV  n=rdi  alpha=xmm0  x=rsi  y=rdx
  Win64 n=rcx  alpha=xmm1  x=r8    y=r9 }
procedure AxpyAVX2(n: TIndex; alpha: Double; x, y: PDouble); assembler; nostackframe;
asm
{$IFDEF WIN64}
  mov     r10, rcx
  vbroadcastsd ymm0, xmm1
  mov     r11, r8
  mov     r8,  r9
{$ELSE}
  mov     r10, rdi
  vbroadcastsd ymm0, xmm0
  mov     r11, rsi
  mov     r8,  rdx
{$ENDIF}
  test    r10, r10
  jle     @@done
  mov     rax, r10
  shr     rax, 3
  jz      @@tail
  align   16
@@loop:
  vmovupd ymm1, ymmword ptr [r11]
  vmovupd ymm2, ymmword ptr [r8]
  vfmadd231pd ymm2, ymm1, ymm0
  vmovupd ymm1, ymmword ptr [r11 + 32]
  vmovupd ymm3, ymmword ptr [r8  + 32]
  vfmadd231pd ymm3, ymm1, ymm0
  vmovupd ymmword ptr [r8], ymm2
  vmovupd ymmword ptr [r8 + 32], ymm3
  add     r11, 64
  add     r8,  64
  dec     rax
  jnz     @@loop
@@tail:
  and     r10, 7
  jz      @@done
@@tloop:
  vmovsd  xmm1, qword ptr [r11]
  vmulsd  xmm1, xmm1, xmm0
  vaddsd  xmm1, xmm1, qword ptr [r8]
  vmovsd  qword ptr [r8], xmm1
  add     r11, 8
  add     r8,  8
  dec     r10
  jnz     @@tloop
@@done:
  vzeroupper
end;

{ x *= alpha
  SysV  n=rdi  alpha=xmm0  x=rsi
  Win64 n=rcx  alpha=xmm1  x=rdx }
procedure ScaleAVX2(n: TIndex; alpha: Double; x: PDouble); assembler; nostackframe;
asm
{$IFDEF WIN64}
  mov     r10, rcx
  vbroadcastsd ymm0, xmm1
  mov     r11, rdx
{$ELSE}
  mov     r10, rdi
  vbroadcastsd ymm0, xmm0
  mov     r11, rsi
{$ENDIF}
  test    r10, r10
  jle     @@done
  mov     rax, r10
  shr     rax, 3
  jz      @@tail
  align   16
@@loop:
  vmulpd  ymm1, ymm0, ymmword ptr [r11]
  vmulpd  ymm2, ymm0, ymmword ptr [r11 + 32]
  vmovupd ymmword ptr [r11], ymm1
  vmovupd ymmword ptr [r11 + 32], ymm2
  add     r11, 64
  dec     rax
  jnz     @@loop
@@tail:
  and     r10, 7
  jz      @@done
@@tloop:
  vmulsd  xmm1, xmm0, qword ptr [r11]
  vmovsd  qword ptr [r11], xmm1
  add     r11, 8
  dec     r10
  jnz     @@tloop
@@done:
  vzeroupper
end;

procedure CopyAVX2(n: TIndex; src, dst: PDouble); assembler; nostackframe;
asm
{$IFDEF WIN64}
  mov     r9,  rcx
  mov     r10, rdx
  mov     r11, r8
{$ELSE}
  mov     r9,  rdi
  mov     r10, rsi
  mov     r11, rdx
{$ENDIF}
  test    r9, r9
  jle     @@done
  mov     rax, r9
  shr     rax, 3
  jz      @@tail
  align   16
@@loop:
  vmovupd ymm0, ymmword ptr [r10]
  vmovupd ymm1, ymmword ptr [r10 + 32]
  vmovupd ymmword ptr [r11], ymm0
  vmovupd ymmword ptr [r11 + 32], ymm1
  add     r10, 64
  add     r11, 64
  dec     rax
  jnz     @@loop
@@tail:
  and     r9, 7
  jz      @@done
@@tloop:
  vmovsd  xmm0, qword ptr [r10]
  vmovsd  qword ptr [r11], xmm0
  add     r10, 8
  add     r11, 8
  dec     r9
  jnz     @@tloop
@@done:
  vzeroupper
end;
{$ENDIF}

procedure KernelCopy(n: TIndex; src, dst: PDouble);
begin
  if (n <= 0) or (src = dst) then Exit;
{$IFDEF CPUX86_64}
  if (n >= 16) and CpuHasAVX2FMA then
    CopyAVX2(n, src, dst)
  else
{$ENDIF}
    KernelCopy_Pas(n, src, dst);
end;

procedure KernelScale(n: TIndex; alpha: Double; x: PDouble);
begin
  if n <= 0 then Exit;
{$IFDEF CPUX86_64}
  if (n >= 16) and CpuHasAVX2FMA and (alpha <> 0.0) then
    ScaleAVX2(n, alpha, x)
  else
{$ENDIF}
    KernelScale_Pas(n, alpha, x);
end;

procedure KernelAxpy(n: TIndex; alpha: Double; x, y: PDouble);
begin
  if (n <= 0) or (alpha = 0.0) then Exit;
{$IFDEF CPUX86_64}
  if (n >= 16) and CpuHasAVX2FMA then
    AxpyAVX2(n, alpha, x, y)
  else
{$ENDIF}
    KernelAxpy_Pas(n, alpha, x, y);
end;

function KernelDot(n: TIndex; x, y: PDouble): Double;
begin
  if n <= 0 then Exit(0.0);
{$IFDEF CPUX86_64}
  if (n >= 16) and CpuHasAVX2FMA then
    Result := DotAVX2(n, x, y)
  else
{$ENDIF}
    Result := KernelDot_Pas(n, x, y);
end;

function KernelNrm2(n: TIndex; x: PDouble): Double;
begin
  Result := Sqrt(KernelDot(n, x, x));
end;

procedure VecCopy(const x: TVec; var y: TVec);
var
  n: TIndex;
begin
  n := x.n;
  if y.n < n then n := y.n;
  KernelCopy(n, x.data, y.data);
end;

procedure VecScale(alpha: Double; var x: TVec);
begin
  KernelScale(x.n, alpha, x.data);
end;

procedure VecAxpy(alpha: Double; const x: TVec; var y: TVec);
var
  n: TIndex;
begin
  n := x.n;
  if y.n < n then n := y.n;
  KernelAxpy(n, alpha, x.data, y.data);
end;

function VecDot(const x, y: TVec): Double;
var
  n: TIndex;
begin
  n := x.n;
  if y.n < n then n := y.n;
  Result := KernelDot(n, x.data, y.data);
end;

function VecNrm2(const x: TVec): Double;
begin
  Result := KernelNrm2(x.n, x.data);
end;

function VecAsum(const x: TVec): Double;
var
  i: TIndex;
  s: Double;
begin
  s := 0.0;
  for i := 0 to x.n - 1 do
    s := s + Abs(x.data[i]);
  Result := s;
end;

function VecAmax(const x: TVec): Double;
var
  i: TIndex;
  a, v: Double;
begin
  a := 0.0;
  for i := 0 to x.n - 1 do
  begin
    v := Abs(x.data[i]);
    if v > a then a := v;
  end;
  Result := a;
end;

procedure VecHadamard(const x: TVec; var y: TVec);
var
  i, n: TIndex;
begin
  n := x.n;
  if y.n < n then n := y.n;
  for i := 0 to n - 1 do
    y.data[i] := y.data[i] * x.data[i];
end;

procedure VecWAXPBY(alpha: Double; const x: TVec; beta: Double; const y: TVec; var w: TVec);
var
  i, n: TIndex;
begin
  n := x.n;
  if y.n < n then n := y.n;
  if w.n < n then n := w.n;
  for i := 0 to n - 1 do
    w.data[i] := alpha * x.data[i] + beta * y.data[i];
end;

end.
