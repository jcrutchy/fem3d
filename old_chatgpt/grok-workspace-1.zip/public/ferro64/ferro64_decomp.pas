{ Dense factorizations: blocked Cholesky (SPD), LU with partial pivoting, QR.
  These are the workhorses behind small / condensed FEA systems. }
unit ferro64_decomp;

{$mode objfpc}{$H+}

interface

uses
  ferro64_types;

{ In-place lower Cholesky A := L, A = L L^T. Returns False if not SPD. }
function  MatChol(var A: TMat): Boolean;
procedure MatCholSolve(const L: TMat; var x: TVec);

{ In-place LU with partial pivoting. ipiv[i] is the row swapped with i. }
function  MatLU(var A: TMat; ipiv: PIndex): Boolean;
procedure MatLUSolve(const LU: TMat; ipiv: PIndex; var x: TVec);

{ Thin QR via Householder. A overwritten with R in the upper triangle;
  v vectors below the diagonal. tau length min(m,n). }
procedure MatQR(var A: TMat; tau: PDouble);
procedure MatQRSolve(const QR: TMat; tau: PDouble; var x: TVec);

{ Convenience: solve A x = b for SPD (Cholesky) or general (LU). }
function  MatSolveSPD(var A: TMat; var x: TVec): Boolean;
function  MatSolveGen(var A: TMat; var x: TVec): Boolean;

implementation

uses
  Math, ferro64_vec, ferro64_mat;

function MatChol(var A: TMat): Boolean;
var
  j, k, n: TIndex;
  d, s: Double;
  colj, colk: PDouble;
begin
  n := A.rows;
  if A.cols < n then n := A.cols;
  for j := 0 to n - 1 do
  begin
    colj := MatCol(A, j);
    for k := 0 to j - 1 do
    begin
      colk := MatCol(A, k);
      KernelAxpy(n - j, -colk[j], @colk[j], @colj[j]);
    end;
    d := colj[j];
    if (d <= 0.0) or (d <> d) then
      Exit(False);
    s := Sqrt(d);
    colj[j] := s;
    KernelScale(n - j - 1, 1.0 / s, @colj[j + 1]);
  end;
  Result := True;
end;

procedure MatCholSolve(const L: TMat; var x: TVec);
var
  j, n: TIndex;
  col: PDouble;
begin
  n := L.rows;
  { L y = b }
  for j := 0 to n - 1 do
  begin
    col := MatCol(L, j);
    x.data[j] := x.data[j] / col[j];
    KernelAxpy(n - j - 1, -x.data[j], @col[j + 1], @x.data[j + 1]);
  end;
  { L^T x = y }
  for j := n - 1 downto 0 do
  begin
    col := MatCol(L, j);
    x.data[j] := x.data[j] - KernelDot(n - j - 1, @col[j + 1], @x.data[j + 1]);
    x.data[j] := x.data[j] / col[j];
  end;
end;

function MatLU(var A: TMat; ipiv: PIndex): Boolean;
var
  i, j, k, n, p, m: TIndex;
  maxv, t, piv: Double;
  colk, colj: PDouble;
begin
  n := A.rows;
  if A.cols < n then n := A.cols;
  m := A.rows;
  for k := 0 to n - 1 do
  begin
    { pivot }
    colk := MatCol(A, k);
    p := k;
    maxv := Abs(colk[k]);
    for i := k + 1 to m - 1 do
    begin
      t := Abs(colk[i]);
      if t > maxv then
      begin
        maxv := t;
        p := i;
      end;
    end;
    ipiv[k] := p;
    if maxv < FERRO_EPS * 8 then
      Exit(False);
    if p <> k then
      for j := 0 to A.cols - 1 do
      begin
        t := A.data[k + j * A.ld];
        A.data[k + j * A.ld] := A.data[p + j * A.ld];
        A.data[p + j * A.ld] := t;
      end;
    piv := 1.0 / colk[k];
    for i := k + 1 to m - 1 do
      colk[i] := colk[i] * piv;
    for j := k + 1 to A.cols - 1 do
    begin
      colj := MatCol(A, j);
      KernelAxpy(m - k - 1, -colj[k], @colk[k + 1], @colj[k + 1]);
    end;
  end;
  Result := True;
end;

procedure MatLUSolve(const LU: TMat; ipiv: PIndex; var x: TVec);
var
  i, k, n, p: TIndex;
  t: Double;
  col: PDouble;
begin
  n := LU.rows;
  if LU.cols < n then n := LU.cols;
  for k := 0 to n - 1 do
  begin
    p := ipiv[k];
    if p <> k then
    begin
      t := x.data[k];
      x.data[k] := x.data[p];
      x.data[p] := t;
    end;
  end;
  { L y = Pb  (unit diagonal) }
  for k := 0 to n - 1 do
  begin
    col := MatCol(LU, k);
    KernelAxpy(n - k - 1, -x.data[k], @col[k + 1], @x.data[k + 1]);
  end;
  { U x = y  — U is upper, so row k is not contiguous in column-major. }
  for k := n - 1 downto 0 do
  begin
    t := x.data[k];
    for i := k + 1 to n - 1 do
      t := t - LU.data[k + i * LU.ld] * x.data[i];
    x.data[k] := t / LU.data[k + k * LU.ld];
  end;
  i := 0; { keep compiler quiet on unused if any }
end;

procedure HouseholderCol(n: TIndex; x: PDouble; out tau, beta: Double);
var
  s, x0, mu: Double;
begin
  if n <= 0 then
  begin
    tau := 0; beta := 0; Exit;
  end;
  x0 := x[0];
  s := KernelDot(n - 1, @x[1], @x[1]);
  if s = 0.0 then
  begin
    tau := 0; beta := x0; Exit;
  end;
  mu := Sqrt(x0 * x0 + s);
  if x0 >= 0 then
    beta := -mu
  else
    beta := mu;
  tau := (beta - x0) / beta;
  KernelScale(n - 1, 1.0 / (x0 - beta), @x[1]);
  x[0] := 1.0;
end;

procedure MatQR(var A: TMat; tau: PDouble);
var
  k, m, n, j: TIndex;
  beta, tk, dot: Double;
  colk, colj: PDouble;
  v: TVec;
begin
  m := A.rows;
  n := A.cols;
  v := VecMake(m);
  for k := 0 to n - 1 do
  begin
    if k >= m then Break;
    colk := MatCol(A, k);
    HouseholderCol(m - k, @colk[k], tk, beta);
    tau[k] := tk;
    colk[k] := beta;
    if tk = 0.0 then Continue;
    { apply I - tau v v^T to remaining columns }
    v.data[0] := 1.0;
    KernelCopy(m - k - 1, @colk[k + 1], @v.data[1]);
    for j := k + 1 to n - 1 do
    begin
      colj := MatCol(A, j);
      dot := colj[k] + KernelDot(m - k - 1, @v.data[1], @colj[k + 1]);
      dot := tk * dot;
      colj[k] := colj[k] - dot;
      KernelAxpy(m - k - 1, -dot, @v.data[1], @colj[k + 1]);
    end;
  end;
  VecFree(v);
end;

procedure MatQRSolve(const QR: TMat; tau: PDouble; var x: TVec);
var
  k, m, n, j: TIndex;
  dot: Double;
  col: PDouble;
begin
  m := QR.rows;
  n := QR.cols;
  { Q^T b }
  for k := 0 to n - 1 do
  begin
    if tau[k] = 0.0 then Continue;
    col := MatCol(QR, k);
    dot := x.data[k] + KernelDot(m - k - 1, @col[k + 1], @x.data[k + 1]);
    dot := tau[k] * dot;
    x.data[k] := x.data[k] - dot;
    KernelAxpy(m - k - 1, -dot, @col[k + 1], @x.data[k + 1]);
  end;
  { R x = Q^T b  — R is upper, row-wise. }
  for k := n - 1 downto 0 do
  begin
    dot := x.data[k];
    for j := k + 1 to n - 1 do
      dot := dot - QR.data[k + j * QR.ld] * x.data[j];
    x.data[k] := dot / QR.data[k + k * QR.ld];
  end;
end;

function MatSolveSPD(var A: TMat; var x: TVec): Boolean;
begin
  Result := MatChol(A);
  if Result then
    MatCholSolve(A, x);
end;

function MatSolveGen(var A: TMat; var x: TVec): Boolean;
var
  ipiv: PIndex;
begin
  ipiv := PIndex(FerroAlloc(A.rows * SizeOf(TIndex)));
  Result := MatLU(A, ipiv);
  if Result then
    MatLUSolve(A, ipiv, x);
  FerroFree(ipiv);
end;

end.
