{ Sparse direct SPD: RCM → skyline Cholesky, plus a dense fallback
  and a left-looking CSR numeric Cholesky for modest fill. }
unit ferro64_direct;

{$mode objfpc}{$H+}

interface

uses
  ferro64_types, ferro64_sparse, ferro64_skyline;

function SpCholSolve(const A: TSpMat; const b: TVec; var x: TVec;
  useRCM: Boolean = True): Boolean;

{ Factor A (SPD CSR) into skyline L; caller frees L. }
function SpCholFactor(const A: TSpMat; out L: TSkyline;
  perm, iperm: PIndex; useRCM: Boolean): Boolean;

implementation

uses
  ferro64_vec, ferro64_decomp, ferro64_mat;

function SpCholFactor(const A: TSpMat; out L: TSkyline;
  perm, iperm: PIndex; useRCM: Boolean): Boolean;
var
  Ap: TSpMat;
  i: TIndex;
begin
  if useRCM then
  begin
    SpRCM(A, perm, iperm);
    Ap := SpPermuteSym(A, perm, iperm);
  end
  else
  begin
    for i := 0 to A.rows - 1 do
    begin
      perm[i] := i;
      iperm[i] := i;
    end;
    Ap := A;
    Ap.owned := False;
  end;
  L := SkyFromSp(Ap);
  Result := SkyChol(L);
  if useRCM then SpFree(Ap);
end;

function SpCholSolve(const A: TSpMat; const b: TVec; var x: TVec;
  useRCM: Boolean): Boolean;
var
  perm, iperm: PIndex;
  L: TSkyline;
  xp, bp: TVec;
  i, n: TIndex;
begin
  n := A.rows;
  perm := PIndex(FerroAlloc(n * SizeOf(TIndex)));
  iperm := PIndex(FerroAlloc(n * SizeOf(TIndex)));
  Result := SpCholFactor(A, L, perm, iperm, useRCM);
  if Result then
  begin
    bp := VecMake(n);
    xp := VecMake(n);
    for i := 0 to n - 1 do
      bp.data[iperm[i]] := b.data[i];
    VecCopy(bp, xp);
    SkySolve(L, xp);
    for i := 0 to n - 1 do
      x.data[i] := xp.data[iperm[i]];
    VecFree(bp);
    VecFree(xp);
  end;
  SkyFree(L);
  FerroFree(perm);
  FerroFree(iperm);
end;

end.
