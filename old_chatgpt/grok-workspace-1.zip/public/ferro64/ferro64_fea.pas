{ Finite-element assembly helpers: 2-D truss, CST plane-stress triangle,
  Dirichlet elimination, von Mises recovery. Procedural, no objects. }
unit ferro64_fea;

{$mode objfpc}{$H+}

interface

uses
  ferro64_types, ferro64_sparse;

type
  TNode2 = record
    x, y: Double;
  end;
  PNode2 = ^TNode2;

  TTri3 = record
    n: array[0..2] of TIndex;
  end;
  PTri3 = ^TTri3;

  TBar2 = record
    n: array[0..1] of TIndex;
    A, E: Double;
  end;

  TFeaMesh2 = record
    nnode, ntri: TIndex;
    node: PNode2;
    tri:  PTri3;
    E, nu, thick: Double;
    owned: Boolean;
  end;

  TFeaSystem = record
    ndof: TIndex;
    K: TSpMat;
    f: TVec;
    fixed: PByte;     { 1 = Dirichlet on that dof }
    ufix:  PDouble;   { prescribed value }
  end;

procedure MeshFree(var m: TFeaMesh2);
function  MeshRect(nx, ny: TIndex; Lx, Ly: Double; E, nu, thick: Double): TFeaMesh2;

procedure CstKe(const n0, n1, n2: TNode2; E, nu, thick: Double;
  out Ke: array of Double; out Be: array of Double; out area: Double);
{ Ke is 6x6 row-major, Be is 3x6 row-major. }

procedure AssembleCst(const mesh: TFeaMesh2; var trip: TTriplets);
procedure AssembleLoadTip(const mesh: TFeaMesh2; Py: Double; var f: TVec);
procedure FixEdgeX0(const mesh: TFeaMesh2; var sys: TFeaSystem);

function  SysFromMesh(const mesh: TFeaMesh2): TFeaSystem;
procedure SysFree(var s: TFeaSystem);
procedure ApplyDirichlet(var s: TFeaSystem);

{ Recover CST von Mises at element centroids. vm length = ntri. }
procedure RecoverVonMises(const mesh: TFeaMesh2; const u: TVec; vm: PDouble);

implementation

uses
  Math, ferro64_vec;

procedure MeshFree(var m: TFeaMesh2);
begin
  if m.owned then
  begin
    FerroFree(m.node);
    FerroFree(m.tri);
  end;
  m.node := nil;
  m.tri := nil;
  m.nnode := 0;
  m.ntri := 0;
  m.owned := False;
end;

function MeshRect(nx, ny: TIndex; Lx, Ly: Double; E, nu, thick: Double): TFeaMesh2;
var
  i, j, ix, nxp, nyp, t: TIndex;
  dx, dy: Double;
begin
  if nx < 1 then nx := 1;
  if ny < 1 then ny := 1;
  nxp := nx + 1;
  nyp := ny + 1;
  Result.nnode := nxp * nyp;
  Result.ntri := nx * ny * 2;
  Result.node := PNode2(FerroAlloc(Result.nnode * SizeOf(TNode2)));
  Result.tri := PTri3(FerroAlloc(Result.ntri * SizeOf(TTri3)));
  Result.E := E;
  Result.nu := nu;
  Result.thick := thick;
  Result.owned := True;
  dx := Lx / nx;
  dy := Ly / ny;
  for j := 0 to nyp - 1 do
    for i := 0 to nxp - 1 do
    begin
      ix := i + j * nxp;
      Result.node[ix].x := i * dx;
      Result.node[ix].y := j * dy;
    end;
  t := 0;
  for j := 0 to ny - 1 do
    for i := 0 to nx - 1 do
    begin
      { n0--n1
        |  / |
        n3--n2  wait: row-major ix = i + j*(nx+1)
        n00 = i + j*nxp, n10 = i+1 + j*nxp
        n01 = i + (j+1)*nxp, n11 = i+1 + (j+1)*nxp }
      Result.tri[t].n[0] := i + j * nxp;
      Result.tri[t].n[1] := (i + 1) + j * nxp;
      Result.tri[t].n[2] := i + (j + 1) * nxp;
      Inc(t);
      Result.tri[t].n[0] := (i + 1) + j * nxp;
      Result.tri[t].n[1] := (i + 1) + (j + 1) * nxp;
      Result.tri[t].n[2] := i + (j + 1) * nxp;
      Inc(t);
    end;
end;

procedure CstKe(const n0, n1, n2: TNode2; E, nu, thick: Double;
  out Ke: array of Double; out Be: array of Double; out area: Double);
var
  b0, b1, b2, c0, c1, c2, det, D00, D01, D22, scale: Double;
  i, j, p, q: Integer;
  DB: array[0..2, 0..5] of Double;
begin
  b0 := n1.y - n2.y; b1 := n2.y - n0.y; b2 := n0.y - n1.y;
  c0 := n2.x - n1.x; c1 := n0.x - n2.x; c2 := n1.x - n0.x;
  det := n0.x * (n1.y - n2.y) + n1.x * (n2.y - n0.y) + n2.x * (n0.y - n1.y);
  area := 0.5 * det;
  if Abs(area) < 1e-18 then
  begin
    FillChar(Ke[0], Length(Ke) * SizeOf(Double), 0);
    FillChar(Be[0], Length(Be) * SizeOf(Double), 0);
    Exit;
  end;
  { B is 3x6, B = 1/(2A) * [b0 0 b1 0 b2 0; 0 c0 0 c1 0 c2; c0 b0 c1 b1 c2 b2] }
  scale := 1.0 / det; { 1/(2A) }
  FillChar(Be[0], 18 * SizeOf(Double), 0);
  Be[0] := b0 * scale; Be[2] := b1 * scale; Be[4] := b2 * scale;
  Be[7] := c0 * scale; Be[9] := c1 * scale; Be[11] := c2 * scale;
  Be[12] := c0 * scale; Be[13] := b0 * scale;
  Be[14] := c1 * scale; Be[15] := b1 * scale;
  Be[16] := c2 * scale; Be[17] := b2 * scale;
  { plane-stress D }
  D00 := E / (1.0 - nu * nu);
  D01 := D00 * nu;
  D22 := E / (2.0 * (1.0 + nu));
  for q := 0 to 5 do
  begin
    DB[0, q] := D00 * Be[q]     + D01 * Be[6 + q];
    DB[1, q] := D01 * Be[q]     + D00 * Be[6 + q];
    DB[2, q] := D22 * Be[12 + q];
  end;
  FillChar(Ke[0], 36 * SizeOf(Double), 0);
  for i := 0 to 5 do
    for j := 0 to 5 do
      Ke[i * 6 + j] := (DB[0, i] * Be[j] + DB[1, i] * Be[6 + j] +
        DB[2, i] * Be[12 + j]) * Abs(area) * thick;
  p := 0;
end;

procedure AssembleCst(const mesh: TFeaMesh2; var trip: TTriplets);
var
  e, a, b, ia, ib, pa, pb: TIndex;
  Ke: array[0..35] of Double;
  Be: array[0..17] of Double;
  area: Double;
  gdof: array[0..5] of TIndex;
begin
  for e := 0 to mesh.ntri - 1 do
  begin
    CstKe(mesh.node[mesh.tri[e].n[0]], mesh.node[mesh.tri[e].n[1]],
      mesh.node[mesh.tri[e].n[2]], mesh.E, mesh.nu, mesh.thick, Ke, Be, area);
    for a := 0 to 2 do
    begin
      gdof[2 * a    ] := 2 * mesh.tri[e].n[a];
      gdof[2 * a + 1] := 2 * mesh.tri[e].n[a] + 1;
    end;
    for a := 0 to 5 do
      for b := 0 to 5 do
      begin
        ia := gdof[a];
        ib := gdof[b];
        pa := a; pb := b;
        TripAdd(trip, ia, ib, Ke[pa * 6 + pb]);
      end;
  end;
end;

procedure AssembleLoadTip(const mesh: TFeaMesh2; Py: Double; var f: TVec);
var
  i, nxp, count: TIndex;
  share: Double;
begin
  nxp := 0;
  { nodes with max x }
  count := 0;
  for i := 0 to mesh.nnode - 1 do
    if mesh.node[i].x >= mesh.node[mesh.nnode - 1].x - 1e-12 then
      Inc(count);
  if count = 0 then Exit;
  share := Py / count;
  for i := 0 to mesh.nnode - 1 do
    if mesh.node[i].x >= mesh.node[mesh.nnode - 1].x - 1e-12 then
      f.data[2 * i + 1] := f.data[2 * i + 1] + share;
  nxp := nxp;
end;

function SysFromMesh(const mesh: TFeaMesh2): TFeaSystem;
var
  trip: TTriplets;
begin
  Result.ndof := mesh.nnode * 2;
  Result.f := VecMake(Result.ndof);
  Result.fixed := PByte(FerroAlloc(Result.ndof));
  Result.ufix := PDouble(FerroAlloc(Result.ndof * SizeOf(Double)));
  trip := TripMake(mesh.ntri * 36);
  AssembleCst(mesh, trip);
  Result.K := SpFromTriplets(Result.ndof, Result.ndof, trip);
  TripFree(trip);
end;

procedure SysFree(var s: TFeaSystem);
begin
  SpFree(s.K);
  VecFree(s.f);
  FerroFree(s.fixed);
  FerroFree(s.ufix);
  s.fixed := nil;
  s.ufix := nil;
  s.ndof := 0;
end;

procedure FixEdgeX0(const mesh: TFeaMesh2; var sys: TFeaSystem);
var
  i: TIndex;
begin
  for i := 0 to mesh.nnode - 1 do
    if mesh.node[i].x <= 1e-14 then
    begin
      sys.fixed[2 * i    ] := 1;
      sys.fixed[2 * i + 1] := 1;
      sys.ufix[2 * i    ] := 0;
      sys.ufix[2 * i + 1] := 0;
    end;
end;

procedure ApplyDirichlet(var s: TFeaSystem);
var
  i, k: TIndex;
  diag: Double;
begin
  for i := 0 to s.ndof - 1 do
  begin
    if s.fixed[i] = 0 then Continue;
    diag := 0.0;
    for k := s.K.rowPtr[i] to s.K.rowPtr[i + 1] - 1 do
      if s.K.colInd[k] = i then
        diag := s.K.val[k];
    if Abs(diag) = 0 then diag := 1.0;
    for k := s.K.rowPtr[i] to s.K.rowPtr[i + 1] - 1 do
      if s.K.colInd[k] = i then
        s.K.val[k] := diag
      else
        s.K.val[k] := 0.0;
    s.f.data[i] := diag * s.ufix[i];
  end;
  for i := 0 to s.ndof - 1 do
  begin
    if s.fixed[i] <> 0 then Continue;
    for k := s.K.rowPtr[i] to s.K.rowPtr[i + 1] - 1 do
      if s.fixed[s.K.colInd[k]] <> 0 then
        s.K.val[k] := 0.0;
  end;
end;

procedure RecoverVonMises(const mesh: TFeaMesh2; const u: TVec; vm: PDouble);
var
  e, a: TIndex;
  Ke: array[0..35] of Double;
  Be: array[0..17] of Double;
  area, sx, sy, txy, D00, D01, D22: Double;
  ue: array[0..5] of Double;
  eps: array[0..2] of Double;
begin
  D00 := mesh.E / (1.0 - mesh.nu * mesh.nu);
  D01 := D00 * mesh.nu;
  D22 := mesh.E / (2.0 * (1.0 + mesh.nu));
  for e := 0 to mesh.ntri - 1 do
  begin
    CstKe(mesh.node[mesh.tri[e].n[0]], mesh.node[mesh.tri[e].n[1]],
      mesh.node[mesh.tri[e].n[2]], mesh.E, mesh.nu, mesh.thick, Ke, Be, area);
    for a := 0 to 2 do
    begin
      ue[2 * a    ] := u.data[2 * mesh.tri[e].n[a]];
      ue[2 * a + 1] := u.data[2 * mesh.tri[e].n[a] + 1];
    end;
    eps[0] := 0; eps[1] := 0; eps[2] := 0;
    for a := 0 to 5 do
    begin
      eps[0] := eps[0] + Be[a] * ue[a];
      eps[1] := eps[1] + Be[6 + a] * ue[a];
      eps[2] := eps[2] + Be[12 + a] * ue[a];
    end;
    sx := D00 * eps[0] + D01 * eps[1];
    sy := D01 * eps[0] + D00 * eps[1];
    txy := D22 * eps[2];
    vm[e] := Sqrt(sx * sx - sx * sy + sy * sy + 3.0 * txy * txy);
  end;
end;

end.
