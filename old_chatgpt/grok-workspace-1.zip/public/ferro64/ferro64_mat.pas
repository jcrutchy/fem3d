{ Level-2/3 BLAS. Column-major GEMV, GER, GEMM.
  GEMM: Goto-style blocking around an 8x4 AVX2+FMA microkernel. }
unit ferro64_mat;

{$mode objfpc}{$H+}
{$IFDEF CPUX86_64}
{$ASMMODE INTEL}
{$ENDIF}

interface

uses
  ferro64_types;

procedure MatCopy(const A: TMat; var B: TMat);
procedure MatScale(alpha: Double; var A: TMat);
procedure MatTrans(const A: TMat; var AT: TMat);

{ y := alpha * op(A) * x + beta * y }
procedure MatGemv(trans: TMatOp; alpha: Double; const A: TMat;
  const x: TVec; beta: Double; var y: TVec);

{ A := alpha * x * y^T + A }
procedure MatGer(alpha: Double; const x, y: TVec; var A: TMat);

{ C := alpha * op(A) * op(B) + beta * C }
procedure MatGemm(transA, transB: TMatOp; alpha: Double;
  const A, B: TMat; beta: Double; var C: TMat);

{ Naive (ijk) GEMM — for correctness checks only. }
procedure MatGemmNaive(alpha: Double; const A, B: TMat; beta: Double; var C: TMat);

function  MatFrob(const A: TMat): Double;

implementation

uses
  ferro64_cpu, ferro64_vec;

procedure MatCopy(const A: TMat; var B: TMat);
var
  j, n: TIndex;
begin
  n := A.rows;
  if B.rows < n then n := B.rows;
  for j := 0 to A.cols - 1 do
  begin
    if j >= B.cols then Break;
    KernelCopy(n, MatCol(A, j), MatCol(B, j));
  end;
end;

procedure MatScale(alpha: Double; var A: TMat);
var
  j: TIndex;
begin
  for j := 0 to A.cols - 1 do
    KernelScale(A.rows, alpha, MatCol(A, j));
end;

procedure MatTrans(const A: TMat; var AT: TMat);
var
  i, j: TIndex;
begin
  for j := 0 to A.cols - 1 do
    for i := 0 to A.rows - 1 do
      AT.data[j + i * AT.ld] := A.data[i + j * A.ld];
end;

procedure MatGemv(trans: TMatOp; alpha: Double; const A: TMat;
  const x: TVec; beta: Double; var y: TVec);
var
  j: TIndex;
  ax: Double;
begin
  KernelScale(y.n, beta, y.data);
  if alpha = 0.0 then Exit;
  if trans = moNoTrans then
  begin
    for j := 0 to A.cols - 1 do
    begin
      if j >= x.n then Break;
      KernelAxpy(A.rows, alpha * x.data[j], MatCol(A, j), y.data);
    end;
  end
  else
  begin
    for j := 0 to A.cols - 1 do
    begin
      if j >= y.n then Break;
      ax := KernelDot(A.rows, MatCol(A, j), x.data);
      y.data[j] := y.data[j] + alpha * ax;
    end;
  end;
end;

procedure MatGer(alpha: Double; const x, y: TVec; var A: TMat);
var
  j: TIndex;
begin
  if alpha = 0.0 then Exit;
  for j := 0 to A.cols - 1 do
  begin
    if j >= y.n then Break;
    KernelAxpy(A.rows, alpha * y.data[j], x.data, MatCol(A, j));
  end;
end;

procedure ApplyBeta(var C: TMat; beta: Double);
var
  j: TIndex;
begin
  if beta = 1.0 then Exit;
  for j := 0 to C.cols - 1 do
    KernelScale(C.rows, beta, MatCol(C, j));
end;

{ Portable 8x4 kernel used as the scalar path. }
procedure Kernel8x4_Pas(k: TIndex; A, B, C: PDouble; ldc: TIndex);
var
  p: TIndex;
  c00,c10,c20,c30,c40,c50,c60,c70: Double;
  c01,c11,c21,c31,c41,c51,c61,c71: Double;
  c02,c12,c22,c32,c42,c52,c62,c72: Double;
  c03,c13,c23,c33,c43,c53,c63,c73: Double;
  a0,a1,a2,a3,a4,a5,a6,a7, b0,b1,b2,b3: Double;
begin
  c00 := C[0];           c10 := C[1];           c20 := C[2];           c30 := C[3];
  c40 := C[4];           c50 := C[5];           c60 := C[6];           c70 := C[7];
  c01 := C[0+ldc];       c11 := C[1+ldc];       c21 := C[2+ldc];       c31 := C[3+ldc];
  c41 := C[4+ldc];       c51 := C[5+ldc];       c61 := C[6+ldc];       c71 := C[7+ldc];
  c02 := C[0+2*ldc];     c12 := C[1+2*ldc];     c22 := C[2+2*ldc];     c32 := C[3+2*ldc];
  c42 := C[4+2*ldc];     c52 := C[5+2*ldc];     c62 := C[6+2*ldc];     c72 := C[7+2*ldc];
  c03 := C[0+3*ldc];     c13 := C[1+3*ldc];     c23 := C[2+3*ldc];     c33 := C[3+3*ldc];
  c43 := C[4+3*ldc];     c53 := C[5+3*ldc];     c63 := C[6+3*ldc];     c73 := C[7+3*ldc];
  for p := 0 to k - 1 do
  begin
    a0 := A[0]; a1 := A[1]; a2 := A[2]; a3 := A[3];
    a4 := A[4]; a5 := A[5]; a6 := A[6]; a7 := A[7];
    b0 := B[0]; b1 := B[1]; b2 := B[2]; b3 := B[3];
    c00 := c00 + a0*b0; c10 := c10 + a1*b0; c20 := c20 + a2*b0; c30 := c30 + a3*b0;
    c40 := c40 + a4*b0; c50 := c50 + a5*b0; c60 := c60 + a6*b0; c70 := c70 + a7*b0;
    c01 := c01 + a0*b1; c11 := c11 + a1*b1; c21 := c21 + a2*b1; c31 := c31 + a3*b1;
    c41 := c41 + a4*b1; c51 := c51 + a5*b1; c61 := c61 + a6*b1; c71 := c71 + a7*b1;
    c02 := c02 + a0*b2; c12 := c12 + a1*b2; c22 := c22 + a2*b2; c32 := c32 + a3*b2;
    c42 := c42 + a4*b2; c52 := c52 + a5*b2; c62 := c62 + a6*b2; c72 := c72 + a7*b2;
    c03 := c03 + a0*b3; c13 := c13 + a1*b3; c23 := c23 + a2*b3; c33 := c33 + a3*b3;
    c43 := c43 + a4*b3; c53 := c53 + a5*b3; c63 := c63 + a6*b3; c73 := c73 + a7*b3;
    Inc(A, FERRO_MR);
    Inc(B, FERRO_NR);
  end;
  C[0] := c00;           C[1] := c10;           C[2] := c20;           C[3] := c30;
  C[4] := c40;           C[5] := c50;           C[6] := c60;           C[7] := c70;
  C[0+ldc] := c01;       C[1+ldc] := c11;       C[2+ldc] := c21;       C[3+ldc] := c31;
  C[4+ldc] := c41;       C[5+ldc] := c51;       C[6+ldc] := c61;       C[7+ldc] := c71;
  C[0+2*ldc] := c02;     C[1+2*ldc] := c12;     C[2+2*ldc] := c22;     C[3+2*ldc] := c32;
  C[4+2*ldc] := c42;     C[5+2*ldc] := c52;     C[6+2*ldc] := c62;     C[7+2*ldc] := c72;
  C[0+3*ldc] := c03;     C[1+3*ldc] := c13;     C[2+3*ldc] := c23;     C[3+3*ldc] := c33;
  C[4+3*ldc] := c43;     C[5+3*ldc] := c53;     C[6+3*ldc] := c63;     C[7+3*ldc] := c73;
end;

{$IFDEF CPUX86_64}
{ k, Apack, Bpack, C, ldc(in doubles)
  SysV: rdi=k rsi=A rdx=B rcx=C r8=ldc }
procedure Kernel8x4_AVX2(k: TIndex; A, B, C: PDouble; ldc: TIndex);
  assembler; nostackframe;
asm
{$IFDEF WIN64}
  push    rbx
  mov     r10, rcx              { k }
  mov     r11, rdx              { A }
  mov     rbx, r8               { B }
  mov     r8,  r9               { C }
  mov     r9,  qword ptr [rsp+48] { ldc — shadow+ret+rbx }
  jmp     @@start
{$ELSE}
  push    rbx
  mov     r10, rdi
  mov     r11, rsi
  mov     rbx, rdx              { B }
  mov     r8,  rcx              { C }
  { r9 = ldc already }
{$ENDIF}
@@start:
  vxorpd  ymm0, ymm0, ymm0      { C col0 rows 0-3 }
  vxorpd  ymm1, ymm1, ymm1      { C col0 rows 4-7 }
  vxorpd  ymm2, ymm2, ymm2
  vxorpd  ymm3, ymm3, ymm3
  vxorpd  ymm4, ymm4, ymm4
  vxorpd  ymm5, ymm5, ymm5
  vxorpd  ymm6, ymm6, ymm6
  vxorpd  ymm7, ymm7, ymm7
  test    r10, r10
  jle     @@store
  align   16
@@loop:
  vmovupd ymm8, ymmword ptr [r11]        { A 0-3 }
  vmovupd ymm9, ymmword ptr [r11 + 32]   { A 4-7 }
  vbroadcastsd ymm10, qword ptr [rbx]
  vfmadd231pd ymm0, ymm8, ymm10
  vfmadd231pd ymm1, ymm9, ymm10
  vbroadcastsd ymm10, qword ptr [rbx + 8]
  vfmadd231pd ymm2, ymm8, ymm10
  vfmadd231pd ymm3, ymm9, ymm10
  vbroadcastsd ymm10, qword ptr [rbx + 16]
  vfmadd231pd ymm4, ymm8, ymm10
  vfmadd231pd ymm5, ymm9, ymm10
  vbroadcastsd ymm10, qword ptr [rbx + 24]
  vfmadd231pd ymm6, ymm8, ymm10
  vfmadd231pd ymm7, ymm9, ymm10
  add     r11, 64
  add     rbx, 32
  dec     r10
  jnz     @@loop
@@store:
  { add into C }
  shl     r9, 3                 { ldc in bytes }
  vaddpd  ymm0, ymm0, ymmword ptr [r8]
  vaddpd  ymm1, ymm1, ymmword ptr [r8 + 32]
  vmovupd ymmword ptr [r8], ymm0
  vmovupd ymmword ptr [r8 + 32], ymm1
  vaddpd  ymm2, ymm2, ymmword ptr [r8 + r9]
  vaddpd  ymm3, ymm3, ymmword ptr [r8 + r9 + 32]
  vmovupd ymmword ptr [r8 + r9], ymm2
  vmovupd ymmword ptr [r8 + r9 + 32], ymm3
  lea     rax, [r9 + r9]
  vaddpd  ymm4, ymm4, ymmword ptr [r8 + rax]
  vaddpd  ymm5, ymm5, ymmword ptr [r8 + rax + 32]
  vmovupd ymmword ptr [r8 + rax], ymm4
  vmovupd ymmword ptr [r8 + rax + 32], ymm5
  lea     rax, [rax + r9]
  vaddpd  ymm6, ymm6, ymmword ptr [r8 + rax]
  vaddpd  ymm7, ymm7, ymmword ptr [r8 + rax + 32]
  vmovupd ymmword ptr [r8 + rax], ymm6
  vmovupd ymmword ptr [r8 + rax + 32], ymm7
  vzeroupper
  pop     rbx
end;
{$ENDIF}

procedure PackA(mc, kc: TIndex; A: PDouble; lda: TIndex; pack: PDouble);
var
  i, p, ib, ir: TIndex;
begin
  i := 0;
  while i + FERRO_MR <= mc do
  begin
    for p := 0 to kc - 1 do
      for ir := 0 to FERRO_MR - 1 do
      begin
        pack^ := A[(i + ir) + p * lda];
        Inc(pack);
      end;
    Inc(i, FERRO_MR);
  end;
  if i < mc then
  begin
    ib := mc - i;
    for p := 0 to kc - 1 do
    begin
      for ir := 0 to ib - 1 do
      begin
        pack^ := A[(i + ir) + p * lda];
        Inc(pack);
      end;
      for ir := ib to FERRO_MR - 1 do
      begin
        pack^ := 0.0;
        Inc(pack);
      end;
    end;
  end;
end;

procedure PackB(kc, nc: TIndex; B: PDouble; ldb: TIndex; pack: PDouble);
var
  j, p, jb, jr: TIndex;
begin
  j := 0;
  while j + FERRO_NR <= nc do
  begin
    for p := 0 to kc - 1 do
      for jr := 0 to FERRO_NR - 1 do
      begin
        pack^ := B[p + (j + jr) * ldb];
        Inc(pack);
      end;
    Inc(j, FERRO_NR);
  end;
  if j < nc then
  begin
    jb := nc - j;
    for p := 0 to kc - 1 do
    begin
      for jr := 0 to jb - 1 do
      begin
        pack^ := B[p + (j + jr) * ldb];
        Inc(pack);
      end;
      for jr := jb to FERRO_NR - 1 do
      begin
        pack^ := 0.0;
        Inc(pack);
      end;
    end;
  end;
end;

procedure GemmNN_Blocked(m, n, k: TIndex; alpha: Double;
  A: PDouble; lda: TIndex; B: PDouble; ldb: TIndex;
  C: PDouble; ldc: TIndex);
var
  jc, pc, ic, jb, pb, ib, jr, ir: TIndex;
  Ap, Bp, Cp: PDouble;
  aPack, bPack: PDouble;
  useAvx: Boolean;
  tmp: array[0..FERRO_MR * FERRO_NR - 1] of Double;
  r, q: TIndex;
  Av, Bv: TMat;
  Cv: TMat;
begin
  if alpha <> 1.0 then
  begin
    { Scale B into a workspace by folding alpha into packing. }
  end;
  useAvx := CpuHasAVX2FMA;
  aPack := PDouble(FerroAlloc(((m + FERRO_MR) * (k + FERRO_KC)) * SizeOf(Double)));
  bPack := PDouble(FerroAlloc(((n + FERRO_NR) * (k + FERRO_KC)) * SizeOf(Double)));
  jc := 0;
  while jc < n do
  begin
    jb := n - jc;
    if jb > FERRO_NC then jb := FERRO_NC;
    pc := 0;
    while pc < k do
    begin
      pb := k - pc;
      if pb > FERRO_KC then pb := FERRO_KC;
      PackB(pb, jb, @B[pc + jc * ldb], ldb, bPack);
      if alpha <> 1.0 then
        KernelScale(((jb + FERRO_NR - 1) div FERRO_NR) * FERRO_NR * pb, alpha, bPack);
      ic := 0;
      while ic < m do
      begin
        ib := m - ic;
        if ib > FERRO_MC then ib := FERRO_MC;
        PackA(ib, pb, @A[ic + pc * lda], lda, aPack);
        ir := 0;
        while ir < ib do
        begin
          jr := 0;
          while jr < jb do
          begin
            Ap := @aPack[ir * pb]; { packed as (ib_tiles of MR) * pb * MR }
            { A pack layout: for each MR-row panel (ir step MR), kc * MR doubles. }
            Ap := @aPack[(ir div FERRO_MR) * (pb * FERRO_MR)];
            Bp := @bPack[(jr div FERRO_NR) * (pb * FERRO_NR)];
            Cp := @C[(ic + ir) + (jc + jr) * ldc];
            if (ir + FERRO_MR <= ib) and (jr + FERRO_NR <= jb) then
            begin
{$IFDEF CPUX86_64}
              if useAvx then
                Kernel8x4_AVX2(pb, Ap, Bp, Cp, ldc)
              else
{$ENDIF}
                Kernel8x4_Pas(pb, Ap, Bp, Cp, ldc);
            end
            else
            begin
              FillChar(tmp, SizeOf(tmp), 0);
{$IFDEF CPUX86_64}
              if useAvx then
                Kernel8x4_AVX2(pb, Ap, Bp, @tmp[0], FERRO_MR)
              else
{$ENDIF}
                Kernel8x4_Pas(pb, Ap, Bp, @tmp[0], FERRO_MR);
              for q := 0 to FERRO_NR - 1 do
                if jr + q < jb then
                  for r := 0 to FERRO_MR - 1 do
                    if ir + r < ib then
                      C[(ic + ir + r) + (jc + jr + q) * ldc] :=
                        C[(ic + ir + r) + (jc + jr + q) * ldc] + tmp[r + q * FERRO_MR];
            end;
            Inc(jr, FERRO_NR);
          end;
          Inc(ir, FERRO_MR);
        end;
        Inc(ic, FERRO_MC);
      end;
      Inc(pc, FERRO_KC);
    end;
    Inc(jc, FERRO_NC);
  end;
  FerroFree(aPack);
  FerroFree(bPack);
  { silence unused }
  Av.rows := 0; Bv.rows := 0; Cv.rows := 0;
end;

procedure GemmNN_Axpy(m, n, k: TIndex; alpha: Double;
  A: PDouble; lda: TIndex; B: PDouble; ldb: TIndex;
  C: PDouble; ldc: TIndex);
var
  j, p: TIndex;
  b: Double;
begin
  for j := 0 to n - 1 do
    for p := 0 to k - 1 do
    begin
      b := alpha * B[p + j * ldb];
      if b <> 0.0 then
        KernelAxpy(m, b, @A[p * lda], @C[j * ldc]);
    end;
end;

procedure MatGemmNaive(alpha: Double; const A, B: TMat; beta: Double; var C: TMat);
var
  i, j, p: TIndex;
  s: Double;
begin
  for j := 0 to C.cols - 1 do
    for i := 0 to C.rows - 1 do
    begin
      s := 0.0;
      for p := 0 to A.cols - 1 do
        s := s + A.data[i + p * A.ld] * B.data[p + j * B.ld];
      if beta = 0.0 then
        C.data[i + j * C.ld] := alpha * s
      else
        C.data[i + j * C.ld] := alpha * s + beta * C.data[i + j * C.ld];
    end;
end;

procedure MatGemm(transA, transB: TMatOp; alpha: Double;
  const A, B: TMat; beta: Double; var C: TMat);
var
  TA, TB: TMat;
  PA, PB: TMat;
  m, n, k: TIndex;
  ownA, ownB: Boolean;
begin
  ApplyBeta(C, beta);
  if alpha = 0.0 then Exit;

  ownA := False;
  ownB := False;
  PA := A;
  PB := B;
  if transA = moTrans then
  begin
    TA := MatMake(A.cols, A.rows);
    MatTrans(A, TA);
    PA := TA;
    ownA := True;
  end;
  if transB = moTrans then
  begin
    TB := MatMake(B.cols, B.rows);
    MatTrans(B, TB);
    PB := TB;
    ownB := True;
  end;

  m := C.rows;
  n := C.cols;
  k := PA.cols;
  if (m < 32) or (n < 32) or (k < 32) then
    GemmNN_Axpy(m, n, k, alpha, PA.data, PA.ld, PB.data, PB.ld, C.data, C.ld)
  else
    GemmNN_Blocked(m, n, k, alpha, PA.data, PA.ld, PB.data, PB.ld, C.data, C.ld);

  if ownA then MatFree(TA);
  if ownB then MatFree(TB);
end;

function MatFrob(const A: TMat): Double;
var
  j: TIndex;
  s: Double;
begin
  s := 0.0;
  for j := 0 to A.cols - 1 do
    s := s + KernelDot(A.rows, MatCol(A, j), MatCol(A, j));
  Result := Sqrt(s);
end;

end.
