program selftest;
{$mode objfpc}{$H+}
uses
  SysUtils, Math, ferro64;

procedure Check(cond: Boolean; const msg: string);
begin
  if not cond then
  begin
    WriteLn('FAIL  ', msg);
    Halt(1);
  end;
  WriteLn('ok    ', msg);
end;

var
  A, B, C, D: TMat;
  x, y, b, r: TVec;
  i, n: NativeInt;
  trip: TTriplets;
  Sp: TSpMat;
  info: TIterInfo;
  ipiv: PIndex;
begin
  WriteLn(FerroBanner);
  n := 8;
  x := VecMake(n);
  y := VecMake(n);
  for i := 0 to n - 1 do
  begin
    x.data[i] := i + 1.0;
    y.data[i] := 2.0;
  end;
  Check(Abs(VecDot(x, y) - 2.0 * (n * (n + 1) / 2)) < 1e-12, 'dot');
  VecAxpy(1.0, x, y);
  Check(Abs(y.data[0] - 3.0) < 1e-12, 'axpy');

  A := MatMake(n, n);
  b := VecMake(n);
  r := VecMake(n);
  for i := 0 to n - 1 do
  begin
    MatSet(A, i, i, 4.0);
    if i > 0 then begin MatSet(A, i, i - 1, -1.0); MatSet(A, i - 1, i, -1.0); end;
    b.data[i] := 1.0;
  end;
  D := MatClone(A);
  x := VecClone(b);
  Check(MatSolveSPD(D, x), 'chol factor');
  MatGemv(moNoTrans, 1.0, A, x, 0.0, r);
  VecAxpy(-1.0, b, r);
  Check(VecNrm2(r) < 1e-10, 'chol solve residual');

  D := MatClone(A);
  VecCopy(b, x);
  ipiv := PIndex(FerroAlloc(n * SizeOf(NativeInt)));
  Check(MatLU(D, ipiv), 'lu factor');
  MatLUSolve(D, ipiv, x);
  MatGemv(moNoTrans, 1.0, A, x, 0.0, r);
  VecAxpy(-1.0, b, r);
  Check(VecNrm2(r) < 1e-10, 'lu solve residual');
  FerroFree(ipiv);

  trip := TripMake(3 * n);
  for i := 0 to n - 1 do
  begin
    TripAdd(trip, i, i, 4.0);
    if i > 0 then TripAddSym(trip, i, i - 1, -1.0);
  end;
  Sp := SpFromTriplets(n, n, trip);
  VecFill(x, 0.0);
  Check(CgSolve(Sp, b, x, 1e-12, 200, info), 'cg');
  Check(info.residual < 1e-10, 'cg residual');
  Check(SpCholSolve(Sp, b, y, True), 'skyline chol');
  VecAxpy(-1.0, x, y);
  Check(VecNrm2(y) < 1e-8, 'cg vs skyline');

  B := MatMake(n, n);
  C := MatMake(n, n);
  MatIdent(B);
  MatGemm(moNoTrans, moNoTrans, 1.0, A, B, 0.0, C);
  Check(Abs(MatFrob(C) - MatFrob(A)) < 1e-10, 'gemm A*I');

  WriteLn('all tests passed');
  VecFree(x); VecFree(y); VecFree(b); VecFree(r);
  MatFree(A); MatFree(B); MatFree(C); MatFree(D);
  TripFree(trip); SpFree(Sp);
end.
