{ FERRO — zero-dependency double-precision linear algebra for FEA.
  Record types, 32-byte aligned alloc, column-major dense layout. }
unit ferro64_types;

{$mode objfpc}{$H+}
{$INLINE ON}

interface

const
  FERRO_VERSION = '1.0.0';
  FERRO_ALIGN   = 32;          { AVX2-friendly }
  FERRO_EPS     = 2.220446049250313e-16;
  FERRO_MR      = 8;           { GEMM microkernel rows }
  FERRO_NR      = 4;           { GEMM microkernel cols }
  FERRO_MC      = 256;
  FERRO_KC      = 256;
  FERRO_NC      = 128;

type
  PNativeInt = ^NativeInt;
  TIndex     = NativeInt;
  PIndex     = ^TIndex;

  { Dense vector. data[0 .. n-1]. }
  TVec = record
    n:     TIndex;
    data:  PDouble;
    owned: Boolean;
  end;
  PVec = ^TVec;

  { Dense matrix, column-major, MATLAB / BLAS / Fortran layout.
    A(i,j) lives at data[i + j*ld], 0-based, i < rows, j < cols. }
  TMat = record
    rows, cols, ld: TIndex;
    data:  PDouble;
    owned: Boolean;
  end;
  PMat = ^TMat;

  { Compressed sparse row. rowPtr has length rows+1. }
  TSpMat = record
    rows, cols, nnz: TIndex;
    rowPtr: PIndex;
    colInd: PIndex;
    val:    PDouble;
    owned:  Boolean;
  end;
  PSpMat = ^TSpMat;

  { Coordinate (triplet) buffer used during FEA assembly. }
  TTriplets = record
    cap, nnz: TIndex;
    ii, jj:   PIndex;
    vv:       PDouble;
    owned:    Boolean;
  end;
  PTriplets = ^TTriplets;

  { Skyline / profile storage of a symmetric matrix (lower triangle).
    Column j holds rows (j - height[j] + 1) .. j inclusive; diagonal is last. }
  TSkyline = record
    n, nnz: TIndex;
    height: PIndex;     { length n; height[j] >= 1 }
    colPtr: PIndex;     { length n+1 }
    val:    PDouble;
    owned:  Boolean;
  end;
  PSkyline = ^TSkyline;

  TMatOp = (moNoTrans, moTrans);

  TIterInfo = record
    iters:      Integer;
    residual:   Double;
    converged:  Boolean;
    elapsedMs:  Double;
  end;

function  FerroAlloc(nbytes: TIndex; align: TIndex = FERRO_ALIGN): Pointer;
procedure FerroFree(p: Pointer);
procedure FerroZero(p: Pointer; nbytes: TIndex);
procedure FerroCopyBytes(dst, src: Pointer; nbytes: TIndex);

function  VecMake(n: TIndex): TVec;
function  VecView(n: TIndex; data: PDouble): TVec;
procedure VecFree(var v: TVec);
procedure VecFill(var v: TVec; alpha: Double);
function  VecClone(const v: TVec): TVec;

function  MatMake(rows, cols: TIndex; ld: TIndex = 0): TMat;
function  MatView(rows, cols, ld: TIndex; data: PDouble): TMat;
procedure MatFree(var A: TMat);
procedure MatFill(var A: TMat; alpha: Double);
procedure MatIdent(var A: TMat);
function  MatClone(const A: TMat): TMat;
function  MatAt(const A: TMat; i, j: TIndex): Double; inline;
procedure MatSet(var A: TMat; i, j: TIndex; v: Double); inline;
function  MatCol(const A: TMat; j: TIndex): PDouble; inline;

function  TripMake(cap: TIndex): TTriplets;
procedure TripFree(var t: TTriplets);
procedure TripAdd(var t: TTriplets; i, j: TIndex; v: Double);
procedure TripAddSym(var t: TTriplets; i, j: TIndex; v: Double);

function  TickUs: QWord;

implementation

uses
  SysUtils;

type
  PPointer = ^Pointer;

function FerroAlloc(nbytes: TIndex; align: TIndex): Pointer;
var
  raw: Pointer;
  aligned: PtrUInt;
  a: PtrUInt;
begin
  Result := nil;
  if nbytes <= 0 then Exit;
  if align < SizeOf(Pointer) then align := SizeOf(Pointer);
  a := PtrUInt(align);
  GetMem(raw, nbytes + TIndex(a) + SizeOf(Pointer));
  if raw = nil then
    raise EOutOfMemory.Create('FERRO: out of memory');
  aligned := (PtrUInt(raw) + PtrUInt(SizeOf(Pointer)) + a - 1) and not (a - 1);
  PPointer(aligned - PtrUInt(SizeOf(Pointer)))^ := raw;
  Result := Pointer(aligned);
  FillChar(Result^, nbytes, 0);
end;

procedure FerroFree(p: Pointer);
begin
  if p = nil then Exit;
  FreeMem(PPointer(PtrUInt(p) - PtrUInt(SizeOf(Pointer)))^);
end;

procedure FerroZero(p: Pointer; nbytes: TIndex);
begin
  if (p <> nil) and (nbytes > 0) then
    FillChar(p^, nbytes, 0);
end;

procedure FerroCopyBytes(dst, src: Pointer; nbytes: TIndex);
begin
  if (dst <> nil) and (src <> nil) and (nbytes > 0) then
    Move(src^, dst^, nbytes);
end;

function VecMake(n: TIndex): TVec;
begin
  Result.n := n;
  Result.owned := True;
  if n > 0 then
    Result.data := PDouble(FerroAlloc(n * SizeOf(Double)))
  else
    Result.data := nil;
end;

function VecView(n: TIndex; data: PDouble): TVec;
begin
  Result.n := n;
  Result.data := data;
  Result.owned := False;
end;

procedure VecFree(var v: TVec);
begin
  if v.owned then
    FerroFree(v.data);
  v.data := nil;
  v.n := 0;
  v.owned := False;
end;

procedure VecFill(var v: TVec; alpha: Double);
var
  i: TIndex;
begin
  if alpha = 0.0 then
    FerroZero(v.data, v.n * SizeOf(Double))
  else
    for i := 0 to v.n - 1 do
      v.data[i] := alpha;
end;

function VecClone(const v: TVec): TVec;
begin
  Result := VecMake(v.n);
  FerroCopyBytes(Result.data, v.data, v.n * SizeOf(Double));
end;

function MatMake(rows, cols: TIndex; ld: TIndex): TMat;
begin
  if ld < rows then ld := rows;
  Result.rows := rows;
  Result.cols := cols;
  Result.ld := ld;
  Result.owned := True;
  if (ld > 0) and (cols > 0) then
    Result.data := PDouble(FerroAlloc(ld * cols * SizeOf(Double)))
  else
    Result.data := nil;
end;

function MatView(rows, cols, ld: TIndex; data: PDouble): TMat;
begin
  Result.rows := rows;
  Result.cols := cols;
  Result.ld := ld;
  Result.data := data;
  Result.owned := False;
end;

procedure MatFree(var A: TMat);
begin
  if A.owned then
    FerroFree(A.data);
  A.data := nil;
  A.rows := 0;
  A.cols := 0;
  A.ld := 0;
  A.owned := False;
end;

procedure MatFill(var A: TMat; alpha: Double);
var
  j, i: TIndex;
  col: PDouble;
begin
  for j := 0 to A.cols - 1 do
  begin
    col := @A.data[j * A.ld];
    if alpha = 0.0 then
      FerroZero(col, A.rows * SizeOf(Double))
    else
      for i := 0 to A.rows - 1 do
        col[i] := alpha;
  end;
end;

procedure MatIdent(var A: TMat);
var
  i, n: TIndex;
begin
  MatFill(A, 0.0);
  n := A.rows;
  if A.cols < n then n := A.cols;
  for i := 0 to n - 1 do
    A.data[i + i * A.ld] := 1.0;
end;

function MatClone(const A: TMat): TMat;
var
  j: TIndex;
begin
  Result := MatMake(A.rows, A.cols, A.rows);
  for j := 0 to A.cols - 1 do
    FerroCopyBytes(@Result.data[j * Result.ld], @A.data[j * A.ld],
      A.rows * SizeOf(Double));
end;

function MatAt(const A: TMat; i, j: TIndex): Double; inline;
begin
  Result := A.data[i + j * A.ld];
end;

procedure MatSet(var A: TMat; i, j: TIndex; v: Double); inline;
begin
  A.data[i + j * A.ld] := v;
end;

function MatCol(const A: TMat; j: TIndex): PDouble; inline;
begin
  Result := @A.data[j * A.ld];
end;

function TripMake(cap: TIndex): TTriplets;
begin
  if cap < 16 then cap := 16;
  Result.cap := cap;
  Result.nnz := 0;
  Result.owned := True;
  Result.ii := PIndex(FerroAlloc(cap * SizeOf(TIndex)));
  Result.jj := PIndex(FerroAlloc(cap * SizeOf(TIndex)));
  Result.vv := PDouble(FerroAlloc(cap * SizeOf(Double)));
end;

procedure TripFree(var t: TTriplets);
begin
  if t.owned then
  begin
    FerroFree(t.ii);
    FerroFree(t.jj);
    FerroFree(t.vv);
  end;
  t.ii := nil;
  t.jj := nil;
  t.vv := nil;
  t.cap := 0;
  t.nnz := 0;
  t.owned := False;
end;

procedure TripGrow(var t: TTriplets);
var
  ncap: TIndex;
  nii, njj: PIndex;
  nvv: PDouble;
begin
  ncap := t.cap * 2;
  if ncap < 32 then ncap := 32;
  nii := PIndex(FerroAlloc(ncap * SizeOf(TIndex)));
  njj := PIndex(FerroAlloc(ncap * SizeOf(TIndex)));
  nvv := PDouble(FerroAlloc(ncap * SizeOf(Double)));
  FerroCopyBytes(nii, t.ii, t.nnz * SizeOf(TIndex));
  FerroCopyBytes(njj, t.jj, t.nnz * SizeOf(TIndex));
  FerroCopyBytes(nvv, t.vv, t.nnz * SizeOf(Double));
  FerroFree(t.ii);
  FerroFree(t.jj);
  FerroFree(t.vv);
  t.ii := nii;
  t.jj := njj;
  t.vv := nvv;
  t.cap := ncap;
end;

procedure TripAdd(var t: TTriplets; i, j: TIndex; v: Double);
begin
  if t.nnz >= t.cap then
    TripGrow(t);
  t.ii[t.nnz] := i;
  t.jj[t.nnz] := j;
  t.vv[t.nnz] := v;
  Inc(t.nnz);
end;

procedure TripAddSym(var t: TTriplets; i, j: TIndex; v: Double);
begin
  TripAdd(t, i, j, v);
  if i <> j then
    TripAdd(t, j, i, v);
end;

function TickUs: QWord;
begin
  Result := GetTickCount64 * 1000;
end;

end.
