{ Classic FEA profile / skyline storage of a symmetric matrix.
  Column j holds the upper-triangle entries (i,j) for
  i = j - height[j] + 1 .. j (diagonal last). After RCM a 2-D mesh
  has O(sqrt(n)) bandwidth; Cholesky is O(n b^2). }
unit ferro64_skyline;

{$mode objfpc}{$H+}

interface

uses
  ferro64_types, ferro64_sparse;

function  SkyFromSp(const A: TSpMat): TSkyline;
procedure SkyFree(var S: TSkyline);
function  SkyChol(var S: TSkyline): Boolean;
procedure SkySolve(const S: TSkyline; var x: TVec);
function  SkyAt(const S: TSkyline; i, j: TIndex): Double;

implementation

function ColStartRow(const S: TSkyline; j: TIndex): TIndex; inline;
begin
  Result := j - S.height[j] + 1;
end;

function SkyPos(const S: TSkyline; i, j: TIndex): TIndex; inline;
{ i <= j, i >= ColStartRow(j). }
begin
  Result := S.colPtr[j] + (i - ColStartRow(S, j));
end;

function SkyAt(const S: TSkyline; i, j: TIndex): Double;
var
  r, c: TIndex;
begin
  if i <= j then begin r := i; c := j; end else begin r := j; c := i; end;
  if r < ColStartRow(S, c) then Exit(0.0);
  Result := S.val[SkyPos(S, r, c)];
end;

procedure SkyFree(var S: TSkyline);
begin
  if S.owned then
  begin
    FerroFree(S.height);
    FerroFree(S.colPtr);
    FerroFree(S.val);
  end;
  S.height := nil;
  S.colPtr := nil;
  S.val := nil;
  S.n := 0;
  S.nnz := 0;
  S.owned := False;
end;

function SkyFromSp(const A: TSpMat): TSkyline;
var
  i, k, j, n, lo, hi: TIndex;
begin
  n := A.rows;
  Result.n := n;
  Result.owned := True;
  Result.height := PIndex(FerroAlloc(n * SizeOf(TIndex)));
  Result.colPtr := PIndex(FerroAlloc((n + 1) * SizeOf(TIndex)));
  for j := 0 to n - 1 do
    Result.height[j] := 1;
  for i := 0 to n - 1 do
    for k := A.rowPtr[i] to A.rowPtr[i + 1] - 1 do
    begin
      j := A.colInd[k];
      if i <= j then begin lo := i; hi := j; end else begin lo := j; hi := i; end;
      if Result.height[hi] < (hi - lo + 1) then
        Result.height[hi] := hi - lo + 1;
    end;
  Result.colPtr[0] := 0;
  for j := 0 to n - 1 do
    Result.colPtr[j + 1] := Result.colPtr[j] + Result.height[j];
  Result.nnz := Result.colPtr[n];
  Result.val := PDouble(FerroAlloc(Result.nnz * SizeOf(Double)));
  for i := 0 to n - 1 do
    for k := A.rowPtr[i] to A.rowPtr[i + 1] - 1 do
    begin
      j := A.colInd[k];
      if i > j then Continue;
      if i >= ColStartRow(Result, j) then
        Result.val[SkyPos(Result, i, j)] :=
          Result.val[SkyPos(Result, i, j)] + A.val[k];
    end;
end;

function SkyChol(var S: TSkyline): Boolean;
{ In-place Cholesky of the packed upper triangle. On exit column j holds
  L(i,j) for i<=j  — i.e. L^T sits in the upper skyline.
  L_ij (i>=j) is stored at SkyPos(j, i). }
var
  j, i, k, n, j0, i0, k0: TIndex;
  s, d: Double;
begin
  n := S.n;
  for j := 0 to n - 1 do
  begin
    j0 := ColStartRow(S, j);
    for i := j0 to j - 1 do
    begin
      i0 := ColStartRow(S, i);
      k0 := j0;
      if i0 > k0 then k0 := i0;
      s := S.val[SkyPos(S, i, j)];
      k := k0;
      while k < i do
      begin
        s := s - S.val[SkyPos(S, k, i)] * S.val[SkyPos(S, k, j)];
        Inc(k);
      end;
      d := S.val[SkyPos(S, i, i)];
      if Abs(d) < FERRO_EPS then Exit(False);
      S.val[SkyPos(S, i, j)] := s / d;
    end;
    s := S.val[SkyPos(S, j, j)];
    for i := j0 to j - 1 do
    begin
      d := S.val[SkyPos(S, i, j)];
      s := s - d * d;
    end;
    if (s <= 0) or (s <> s) then Exit(False);
    S.val[SkyPos(S, j, j)] := Sqrt(s);
  end;
  Result := True;
end;

procedure SkySolve(const S: TSkyline; var x: TVec);
var
  i, j, n, j0: TIndex;
  acc: Double;
begin
  n := S.n;
  { L y = b.  L(j,i) for j>=i stored at SkyPos(i,j).
    Forward: for j, y_j = (b_j - sum_{i<j} L_ji y_i) / L_jj
    L_ji = SkyPos(i,j). }
  for j := 0 to n - 1 do
  begin
    j0 := ColStartRow(S, j);
    acc := x.data[j];
    for i := j0 to j - 1 do
      acc := acc - S.val[SkyPos(S, i, j)] * x.data[i];
    x.data[j] := acc / S.val[SkyPos(S, j, j)];
  end;
  { L^T x = y.  (L^T)_ij = L_ji = SkyPos(i,j) for i<=j.
    Back: for j=n-1..0: x_j = y_j / L_jj; then for i<j: y_i -= L_ji x_j }
  for j := n - 1 downto 0 do
  begin
    acc := x.data[j] / S.val[SkyPos(S, j, j)];
    x.data[j] := acc;
    j0 := ColStartRow(S, j);
    for i := j0 to j - 1 do
      x.data[i] := x.data[i] - S.val[SkyPos(S, i, j)] * acc;
  end;
end;

end.
