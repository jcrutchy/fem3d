{ Sparse matrices: triplets → CSR, SpMV, diagonal extract, RCM ordering.
  CSR is the exchange format; skyline/Cholesky consume it for FEA. }
unit ferro64_sparse;

{$mode objfpc}{$H+}

interface

uses
  ferro64_types;

procedure SpFree(var A: TSpMat);
function  SpFromTriplets(rows, cols: TIndex; const t: TTriplets): TSpMat;
function  SpFromDense(const A: TMat; droptol: Double = 0.0): TSpMat;
procedure SpMV(const A: TSpMat; const x: TVec; var y: TVec);
procedure SpMVScaled(const A: TSpMat; alpha: Double; const x: TVec;
  beta: Double; var y: TVec);
procedure SpDiag(const A: TSpMat; var d: TVec);
function  SpAt(const A: TSpMat; i, j: TIndex): Double;
function  SpNnz(const A: TSpMat): TIndex; inline;
procedure SpResidual(const A: TSpMat; const x, b: TVec; var r: TVec);

{ Reverse Cuthill–McKee permutation for bandwidth reduction. perm[new] = old. }
procedure SpRCM(const A: TSpMat; perm, iperm: PIndex);
function  SpPermuteSym(const A: TSpMat; perm, iperm: PIndex): TSpMat;

implementation

uses
  ferro64_vec;

procedure SpFree(var A: TSpMat);
begin
  if A.owned then
  begin
    FerroFree(A.rowPtr);
    FerroFree(A.colInd);
    FerroFree(A.val);
  end;
  A.rowPtr := nil;
  A.colInd := nil;
  A.val := nil;
  A.rows := 0;
  A.cols := 0;
  A.nnz := 0;
  A.owned := False;
end;

type
  TTripRec = record
    i, j: TIndex;
    v: Double;
  end;
  PTripRec = ^TTripRec;

procedure SortTrips(a: PTripRec; n: TIndex);

  procedure Quick(l, r: TIndex);
  var
    i, j: TIndex;
    pi, pj: TIndex;
    pv: Double;
    t: TTripRec;
  begin
    i := l; j := r;
    pi := a[(l + r) shr 1].i;
    pj := a[(l + r) shr 1].j;
    pv := a[(l + r) shr 1].v;
    repeat
      while (a[i].i < pi) or ((a[i].i = pi) and (a[i].j < pj)) do Inc(i);
      while (a[j].i > pi) or ((a[j].i = pi) and (a[j].j > pj)) do Dec(j);
      if i <= j then
      begin
        t := a[i]; a[i] := a[j]; a[j] := t;
        Inc(i); Dec(j);
      end;
    until i > j;
    if l < j then Quick(l, j);
    if i < r then Quick(i, r);
    pv := pv;
  end;

begin
  if n > 1 then
    Quick(0, n - 1);
end;

function SpFromTriplets(rows, cols: TIndex; const t: TTriplets): TSpMat;
var
  recs: PTripRec;
  k, n, w, lastI, lastJ: TIndex;
  acc: Double;
begin
  Result.rows := rows;
  Result.cols := cols;
  Result.owned := True;
  Result.rowPtr := PIndex(FerroAlloc((rows + 1) * SizeOf(TIndex)));
  if t.nnz = 0 then
  begin
    Result.nnz := 0;
    Result.colInd := nil;
    Result.val := nil;
    Exit;
  end;
  recs := PTripRec(FerroAlloc(t.nnz * SizeOf(TTripRec)));
  for k := 0 to t.nnz - 1 do
  begin
    recs[k].i := t.ii[k];
    recs[k].j := t.jj[k];
    recs[k].v := t.vv[k];
  end;
  SortTrips(recs, t.nnz);

  { count unique after summing duplicates }
  n := 1;
  for k := 1 to t.nnz - 1 do
    if (recs[k].i <> recs[k - 1].i) or (recs[k].j <> recs[k - 1].j) then
      Inc(n);

  Result.nnz := n;
  Result.colInd := PIndex(FerroAlloc(n * SizeOf(TIndex)));
  Result.val := PDouble(FerroAlloc(n * SizeOf(Double)));

  FerroZero(Result.rowPtr, (rows + 1) * SizeOf(TIndex));
  w := 0;
  lastI := recs[0].i;
  lastJ := recs[0].j;
  acc := recs[0].v;
  for k := 1 to t.nnz do
  begin
    if (k = t.nnz) or (recs[k].i <> lastI) or (recs[k].j <> lastJ) then
    begin
      Result.colInd[w] := lastJ;
      Result.val[w] := acc;
      Inc(Result.rowPtr[lastI + 1]);
      Inc(w);
      if k < t.nnz then
      begin
        lastI := recs[k].i;
        lastJ := recs[k].j;
        acc := recs[k].v;
      end;
    end
    else
      acc := acc + recs[k].v;
  end;
  for k := 0 to rows - 1 do
    Result.rowPtr[k + 1] := Result.rowPtr[k + 1] + Result.rowPtr[k];
  FerroFree(recs);
end;

function SpFromDense(const A: TMat; droptol: Double): TSpMat;
var
  t: TTriplets;
  i, j: TIndex;
  v: Double;
begin
  t := TripMake(A.rows * 4);
  for j := 0 to A.cols - 1 do
    for i := 0 to A.rows - 1 do
    begin
      v := A.data[i + j * A.ld];
      if Abs(v) > droptol then
        TripAdd(t, i, j, v);
    end;
  Result := SpFromTriplets(A.rows, A.cols, t);
  TripFree(t);
end;

procedure SpMV(const A: TSpMat; const x: TVec; var y: TVec);
var
  i, k: TIndex;
  s: Double;
begin
  for i := 0 to A.rows - 1 do
  begin
    s := 0.0;
    for k := A.rowPtr[i] to A.rowPtr[i + 1] - 1 do
      s := s + A.val[k] * x.data[A.colInd[k]];
    y.data[i] := s;
  end;
end;

procedure SpMVScaled(const A: TSpMat; alpha: Double; const x: TVec;
  beta: Double; var y: TVec);
var
  i, k: TIndex;
  s: Double;
begin
  for i := 0 to A.rows - 1 do
  begin
    s := 0.0;
    for k := A.rowPtr[i] to A.rowPtr[i + 1] - 1 do
      s := s + A.val[k] * x.data[A.colInd[k]];
    if beta = 0.0 then
      y.data[i] := alpha * s
    else
      y.data[i] := alpha * s + beta * y.data[i];
  end;
end;

procedure SpDiag(const A: TSpMat; var d: TVec);
var
  i, k: TIndex;
begin
  VecFill(d, 0.0);
  for i := 0 to A.rows - 1 do
    for k := A.rowPtr[i] to A.rowPtr[i + 1] - 1 do
      if A.colInd[k] = i then
      begin
        d.data[i] := A.val[k];
        Break;
      end;
end;

function SpAt(const A: TSpMat; i, j: TIndex): Double;
var
  k: TIndex;
begin
  Result := 0.0;
  for k := A.rowPtr[i] to A.rowPtr[i + 1] - 1 do
    if A.colInd[k] = j then
      Exit(A.val[k]);
end;

function SpNnz(const A: TSpMat): TIndex; inline;
begin
  Result := A.nnz;
end;

procedure SpResidual(const A: TSpMat; const x, b: TVec; var r: TVec);
begin
  SpMV(A, x, r);
  { r := b - A x }
  KernelScale(r.n, -1.0, r.data);
  KernelAxpy(r.n, 1.0, b.data, r.data);
end;

procedure SpRCM(const A: TSpMat; perm, iperm: PIndex);
var
  n, i, s, minDeg, deg, v, w, k, head, tail, count, start, p: TIndex;
  visited: PByte;
  q, order: PIndex;
  nbr: array of TIndex;
  nb, a, b: TIndex;
  tmp: TIndex;
begin
  n := A.rows;
  visited := PByte(FerroAlloc(n));
  q := PIndex(FerroAlloc(n * SizeOf(TIndex)));
  order := PIndex(FerroAlloc(n * SizeOf(TIndex)));
  FerroZero(visited, n);
  count := 0;

  while count < n do
  begin
    { peripheral-ish start: unseen min-degree node }
    s := -1;
    minDeg := High(TIndex);
    for i := 0 to n - 1 do
      if visited[i] = 0 then
      begin
        deg := A.rowPtr[i + 1] - A.rowPtr[i];
        if deg < minDeg then
        begin
          minDeg := deg;
          s := i;
        end;
      end;
    if s < 0 then Break;

    head := 0; tail := 0;
    q[tail] := s; Inc(tail);
    visited[s] := 1;
    start := count;
    while head < tail do
    begin
      v := q[head]; Inc(head);
      order[count] := v; Inc(count);
      nb := A.rowPtr[v + 1] - A.rowPtr[v];
      SetLength(nbr, nb);
      a := 0;
      for k := A.rowPtr[v] to A.rowPtr[v + 1] - 1 do
      begin
        w := A.colInd[k];
        if (visited[w] = 0) and (w <> v) then
        begin
          nbr[a] := w;
          Inc(a);
        end;
      end;
      { sort neighbours by degree }
      for p := 1 to a - 1 do
      begin
        tmp := nbr[p];
        b := p;
        while (b > 0) and
          ((A.rowPtr[nbr[b - 1] + 1] - A.rowPtr[nbr[b - 1]]) >
           (A.rowPtr[tmp + 1] - A.rowPtr[tmp])) do
        begin
          nbr[b] := nbr[b - 1];
          Dec(b);
        end;
        nbr[b] := tmp;
      end;
      for p := 0 to a - 1 do
        if visited[nbr[p]] = 0 then
        begin
          visited[nbr[p]] := 1;
          q[tail] := nbr[p];
          Inc(tail);
        end;
    end;
    { reverse this component }
    a := start;
    b := count - 1;
    while a < b do
    begin
      tmp := order[a]; order[a] := order[b]; order[b] := tmp;
      Inc(a); Dec(b);
    end;
  end;

  for i := 0 to n - 1 do
  begin
    perm[i] := order[i];
    iperm[order[i]] := i;
  end;
  FerroFree(visited);
  FerroFree(q);
  FerroFree(order);
end;

function SpPermuteSym(const A: TSpMat; perm, iperm: PIndex): TSpMat;
var
  t: TTriplets;
  i, k, pi, pj: TIndex;
begin
  t := TripMake(A.nnz);
  for i := 0 to A.rows - 1 do
  begin
    pi := iperm[i];
    for k := A.rowPtr[i] to A.rowPtr[i + 1] - 1 do
    begin
      pj := iperm[A.colInd[k]];
      TripAdd(t, pi, pj, A.val[k]);
    end;
  end;
  Result := SpFromTriplets(A.rows, A.cols, t);
  TripFree(t);
end;

end.
