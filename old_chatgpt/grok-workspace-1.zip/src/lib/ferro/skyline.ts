import type { Skyline, SpMat, Vec } from "./types.ts";
import { EPS } from "./types.ts";
import { spPermuteSym, spRCM } from "./sparse.ts";

function colStart(S: Skyline, j: number): number {
  return j - S.height[j]! + 1;
}

function pos(S: Skyline, i: number, j: number): number {
  return S.colPtr[j]! + (i - colStart(S, j));
}

export function skyFromSp(A: SpMat): Skyline {
  const n = A.rows;
  const height = new Int32Array(n);
  height.fill(1);
  for (let i = 0; i < n; i++) {
    for (let k = A.rowPtr[i]!; k < A.rowPtr[i + 1]!; k++) {
      const j = A.colInd[k]!;
      const lo = i < j ? i : j;
      const hi = i < j ? j : i;
      const h = hi - lo + 1;
      if (h > height[hi]!) height[hi] = h;
    }
  }
  const colPtr = new Int32Array(n + 1);
  for (let j = 0; j < n; j++) colPtr[j + 1] = colPtr[j]! + height[j]!;
  const val = new Float64Array(colPtr[n]!);
  const S: Skyline = { n, height, colPtr, val };
  for (let i = 0; i < n; i++) {
    for (let k = A.rowPtr[i]!; k < A.rowPtr[i + 1]!; k++) {
      const j = A.colInd[k]!;
      if (i > j) continue;
      if (i >= colStart(S, j)) S.val[pos(S, i, j)]! += A.val[k]!;
    }
  }
  return S;
}

export function skyChol(S: Skyline): boolean {
  const n = S.n;
  const v = S.val;
  for (let j = 0; j < n; j++) {
    const j0 = colStart(S, j);
    for (let i = j0; i < j; i++) {
      const i0 = colStart(S, i);
      let k = j0 > i0 ? j0 : i0;
      let s = v[pos(S, i, j)]!;
      while (k < i) {
        s -= v[pos(S, k, i)]! * v[pos(S, k, j)]!;
        k++;
      }
      const d = v[pos(S, i, i)]!;
      if (Math.abs(d) < EPS) return false;
      v[pos(S, i, j)] = s / d;
    }
    let s = v[pos(S, j, j)]!;
    for (let i = j0; i < j; i++) {
      const d = v[pos(S, i, j)]!;
      s -= d * d;
    }
    if (!(s > 0) || !Number.isFinite(s)) return false;
    v[pos(S, j, j)] = Math.sqrt(s);
  }
  return true;
}

export function skySolve(S: Skyline, x: Vec): void {
  const n = S.n;
  const v = S.val;
  const xd = x.data;
  for (let j = 0; j < n; j++) {
    const j0 = colStart(S, j);
    let acc = xd[j]!;
    for (let i = j0; i < j; i++) acc -= v[pos(S, i, j)]! * xd[i]!;
    xd[j] = acc / v[pos(S, j, j)]!;
  }
  for (let j = n - 1; j >= 0; j--) {
    const acc = xd[j]! / v[pos(S, j, j)]!;
    xd[j] = acc;
    const j0 = colStart(S, j);
    for (let i = j0; i < j; i++) xd[i]! -= v[pos(S, i, j)]! * acc;
  }
}

export function skySolveSp(
  A: SpMat,
  b: Vec,
  useRCM = true,
): { x: Vec; ok: boolean; profile: number } {
  const n = A.rows;
  let Ap = A;
  let iperm: Int32Array | null = null;
  if (useRCM) {
    const o = spRCM(A);
    iperm = o.iperm;
    Ap = spPermuteSym(A, o.perm, o.iperm);
  }
  const S = skyFromSp(Ap);
  const ok = skyChol(S);
  const x: Vec = { n, data: new Float64Array(n) };
  if (!ok) return { x, ok: false, profile: S.colPtr[n]! };
  if (iperm) {
    for (let i = 0; i < n; i++) x.data[iperm[i]!] = b.data[i]!;
    skySolve(S, x);
    const y = new Float64Array(n);
    for (let i = 0; i < n; i++) y[i] = x.data[iperm[i]!]!;
    x.data.set(y);
  } else {
    x.data.set(b.data);
    skySolve(S, x);
  }
  return { x, ok: true, profile: S.colPtr[n]! };
}
