import type { Mat, Vec } from "./types.ts";
import { EPS } from "./types.ts";
import { axpy, dot, scale } from "./vec.ts";

/** In-place lower Cholesky. Returns false if not SPD. */
export function chol(A: Mat): boolean {
  const n = Math.min(A.rows, A.cols);
  const ld = A.ld;
  const a = A.data;
  for (let j = 0; j < n; j++) {
    const cj = j * ld;
    for (let k = 0; k < j; k++) {
      const ck = k * ld;
      axpy(n - j, -a[j + ck]!, a, a, j + ck, j + cj);
    }
    const d = a[j + cj]!;
    if (!(d > 0) || !Number.isFinite(d)) return false;
    const s = Math.sqrt(d);
    a[j + cj] = s;
    scale(n - j - 1, 1 / s, a, j + 1 + cj);
  }
  return true;
}

export function cholSolve(L: Mat, x: Vec): void {
  const n = L.rows;
  const ld = L.ld;
  const a = L.data;
  const v = x.data;
  for (let j = 0; j < n; j++) {
    const cj = j * ld;
    v[j]! /= a[j + cj]!;
    axpy(n - j - 1, -v[j]!, a, v, j + 1 + cj, j + 1);
  }
  for (let j = n - 1; j >= 0; j--) {
    const cj = j * ld;
    v[j]! -= dot(n - j - 1, a, v, j + 1 + cj, j + 1);
    v[j]! /= a[j + cj]!;
  }
}

export function lu(A: Mat, ipiv: Int32Array): boolean {
  const n = Math.min(A.rows, A.cols);
  const m = A.rows;
  const ld = A.ld;
  const a = A.data;
  for (let k = 0; k < n; k++) {
    let p = k;
    let maxv = Math.abs(a[k + k * ld]!);
    for (let i = k + 1; i < m; i++) {
      const t = Math.abs(a[i + k * ld]!);
      if (t > maxv) {
        maxv = t;
        p = i;
      }
    }
    ipiv[k] = p;
    if (maxv < EPS * 8) return false;
    if (p !== k) {
      for (let j = 0; j < A.cols; j++) {
        const t = a[k + j * ld]!;
        a[k + j * ld] = a[p + j * ld]!;
        a[p + j * ld] = t;
      }
    }
    const piv = 1 / a[k + k * ld]!;
    for (let i = k + 1; i < m; i++) a[i + k * ld]! *= piv;
    for (let j = k + 1; j < A.cols; j++) {
      axpy(m - k - 1, -a[k + j * ld]!, a, a, k + 1 + k * ld, k + 1 + j * ld);
    }
  }
  return true;
}

export function luSolve(LU: Mat, ipiv: Int32Array, x: Vec): void {
  const n = Math.min(LU.rows, LU.cols);
  const ld = LU.ld;
  const a = LU.data;
  const v = x.data;
  for (let k = 0; k < n; k++) {
    const p = ipiv[k]!;
    if (p !== k) {
      const t = v[k]!;
      v[k] = v[p]!;
      v[p] = t;
    }
  }
  for (let k = 0; k < n; k++) {
    axpy(n - k - 1, -v[k]!, a, v, k + 1 + k * ld, k + 1);
  }
  for (let k = n - 1; k >= 0; k--) {
    let s = v[k]!;
    for (let j = k + 1; j < n; j++) s -= a[k + j * ld]! * v[j]!;
    v[k] = s / a[k + k * ld]!;
  }
}

export function solveSPD(A: Mat, x: Vec): boolean {
  if (!chol(A)) return false;
  cholSolve(A, x);
  return true;
}
