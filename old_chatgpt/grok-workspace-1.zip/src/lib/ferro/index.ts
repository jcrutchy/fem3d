export * from "./types.ts";
export * from "./vec.ts";
export * from "./mat.ts";
export * from "./decomp.ts";
export * from "./sparse.ts";
export * from "./skyline.ts";
export * from "./krylov.ts";
export * from "./fea.ts";

export const FERRO_VERSION = "1.0.0";
export const FERRO_KERNEL = "browser-blocked-f64";
