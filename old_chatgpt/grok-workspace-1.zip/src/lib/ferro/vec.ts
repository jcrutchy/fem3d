import type { Vec } from "./types.ts";

export function copy(n: number, src: Float64Array, dst: Float64Array, so = 0, dso = 0): void {
  dst.set(src.subarray(so, so + n), dso);
}

export function scale(n: number, alpha: number, x: Float64Array, xo = 0): void {
  if (alpha === 0) {
    x.fill(0, xo, xo + n);
    return;
  }
  if (alpha === 1) return;
  const end = xo + n;
  for (let i = xo; i < end; i++) x[i]! *= alpha;
}

export function axpy(n: number, alpha: number, x: Float64Array, y: Float64Array, xo = 0, yo = 0): void {
  if (alpha === 0) return;
  let i = 0;
  const n4 = n & ~3;
  for (; i < n4; i += 4) {
    y[yo + i]! += alpha * x[xo + i]!;
    y[yo + i + 1]! += alpha * x[xo + i + 1]!;
    y[yo + i + 2]! += alpha * x[xo + i + 2]!;
    y[yo + i + 3]! += alpha * x[xo + i + 3]!;
  }
  for (; i < n; i++) y[yo + i]! += alpha * x[xo + i]!;
}

export function dot(n: number, x: Float64Array, y: Float64Array, xo = 0, yo = 0): number {
  let s0 = 0, s1 = 0, s2 = 0, s3 = 0;
  let i = 0;
  const n4 = n & ~3;
  for (; i < n4; i += 4) {
    s0 += x[xo + i]! * y[yo + i]!;
    s1 += x[xo + i + 1]! * y[yo + i + 1]!;
    s2 += x[xo + i + 2]! * y[yo + i + 2]!;
    s3 += x[xo + i + 3]! * y[yo + i + 3]!;
  }
  let s = s0 + s1 + s2 + s3;
  for (; i < n; i++) s += x[xo + i]! * y[yo + i]!;
  return s;
}

export function nrm2(n: number, x: Float64Array, xo = 0): number {
  return Math.sqrt(dot(n, x, x, xo, xo));
}

export function vecDot(x: Vec, y: Vec): number {
  return dot(Math.min(x.n, y.n), x.data, y.data);
}

export function vecAxpy(alpha: number, x: Vec, y: Vec): void {
  axpy(Math.min(x.n, y.n), alpha, x.data, y.data);
}

export function vecScale(alpha: number, x: Vec): void {
  scale(x.n, alpha, x.data);
}

export function vecNrm2(x: Vec): number {
  return nrm2(x.n, x.data);
}

export function vecCopy(x: Vec, y: Vec): void {
  copy(Math.min(x.n, y.n), x.data, y.data);
}

export function vecFill(x: Vec, a: number): void {
  x.data.fill(a);
}

export function vecAmax(x: Vec): number {
  let a = 0;
  for (let i = 0; i < x.n; i++) {
    const v = Math.abs(x.data[i]!);
    if (v > a) a = v;
  }
  return a;
}
