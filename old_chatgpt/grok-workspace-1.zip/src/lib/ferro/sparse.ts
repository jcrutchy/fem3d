import type { IterInfo, Mat, SpMat, Triplets, Vec } from "./types.ts";
import { EPS, trip, tripAdd, vec } from "./types.ts";
import { axpy, dot, nrm2, scale } from "./vec.ts";

export function spFromTriplets(rows: number, cols: number, t: Triplets): SpMat {
  const n = t.ii.length;
  const order = new Array<number>(n);
  for (let k = 0; k < n; k++) order[k] = k;
  order.sort((a, b) => {
    const di = t.ii[a]! - t.ii[b]!;
    return di !== 0 ? di : t.jj[a]! - t.jj[b]!;
  });
  const ii: number[] = [];
  const jj: number[] = [];
  const vv: number[] = [];
  for (let p = 0; p < n; p++) {
    const k = order[p]!;
    const i = t.ii[k]!;
    const j = t.jj[k]!;
    const v = t.vv[k]!;
    if (ii.length && ii[ii.length - 1] === i && jj[jj.length - 1] === j) {
      vv[vv.length - 1]! += v;
    } else {
      ii.push(i);
      jj.push(j);
      vv.push(v);
    }
  }
  const nnz = vv.length;
  const rowPtr = new Int32Array(rows + 1);
  const colInd = new Int32Array(nnz);
  const val = new Float64Array(nnz);
  let w = 0;
  for (let r = 0; r < rows; r++) {
    rowPtr[r] = w;
    while (w < nnz && ii[w] === r) {
      colInd[w] = jj[w]!;
      val[w] = vv[w]!;
      w++;
    }
  }
  rowPtr[rows] = nnz;
  return { rows, cols, nnz, rowPtr, colInd, val };
}

export function spFromDense(A: Mat, droptol = 0): SpMat {
  const t = trip();
  for (let j = 0; j < A.cols; j++) {
    for (let i = 0; i < A.rows; i++) {
      const v = A.data[i + j * A.ld]!;
      if (Math.abs(v) > droptol) tripAdd(t, i, j, v);
    }
  }
  return spFromTriplets(A.rows, A.cols, t);
}

export function spmv(A: SpMat, x: Vec, y: Vec): void {
  const { rowPtr, colInd, val } = A;
  const xd = x.data;
  const yd = y.data;
  for (let i = 0; i < A.rows; i++) {
    let s = 0;
    const a = rowPtr[i]!;
    const b = rowPtr[i + 1]!;
    for (let k = a; k < b; k++) s += val[k]! * xd[colInd[k]!]!;
    yd[i] = s;
  }
}

export function spmvScaled(A: SpMat, alpha: number, x: Vec, beta: number, y: Vec): void {
  const { rowPtr, colInd, val } = A;
  const xd = x.data;
  const yd = y.data;
  for (let i = 0; i < A.rows; i++) {
    let s = 0;
    for (let k = rowPtr[i]!; k < rowPtr[i + 1]!; k++) s += val[k]! * xd[colInd[k]!]!;
    yd[i] = beta === 0 ? alpha * s : alpha * s + beta * yd[i]!;
  }
}

export function spDiag(A: SpMat, d: Vec): void {
  d.data.fill(0);
  for (let i = 0; i < A.rows; i++) {
    for (let k = A.rowPtr[i]!; k < A.rowPtr[i + 1]!; k++) {
      if (A.colInd[k] === i) {
        d.data[i] = A.val[k]!;
        break;
      }
    }
  }
}

export function spAt(A: SpMat, i: number, j: number): number {
  for (let k = A.rowPtr[i]!; k < A.rowPtr[i + 1]!; k++) {
    if (A.colInd[k] === j) return A.val[k]!;
  }
  return 0;
}

export function spResidual(A: SpMat, x: Vec, b: Vec, r: Vec): void {
  spmv(A, x, r);
  scale(r.n, -1, r.data);
  axpy(r.n, 1, b.data, r.data);
}

export function spRCM(A: SpMat): { perm: Int32Array; iperm: Int32Array } {
  const n = A.rows;
  const visited = new Uint8Array(n);
  const perm = new Int32Array(n);
  const iperm = new Int32Array(n);
  const q = new Int32Array(n);
  let count = 0;

  const deg = (v: number) => A.rowPtr[v + 1]! - A.rowPtr[v]!;

  while (count < n) {
    let s = -1;
    let minDeg = Infinity;
    for (let i = 0; i < n; i++) {
      if (!visited[i]) {
        const d = deg(i);
        if (d < minDeg) {
          minDeg = d;
          s = i;
        }
      }
    }
    if (s < 0) break;
    let head = 0;
    let tail = 0;
    q[tail++] = s;
    visited[s] = 1;
    const start = count;
    while (head < tail) {
      const v = q[head++]!;
      perm[count++] = v;
      const nbr: number[] = [];
      for (let k = A.rowPtr[v]!; k < A.rowPtr[v + 1]!; k++) {
        const w = A.colInd[k]!;
        if (!visited[w] && w !== v) nbr.push(w);
      }
      nbr.sort((a, b) => deg(a) - deg(b));
      for (const w of nbr) {
        if (!visited[w]) {
          visited[w] = 1;
          q[tail++] = w;
        }
      }
    }
    let a = start;
    let b = count - 1;
    while (a < b) {
      const t = perm[a]!;
      perm[a] = perm[b]!;
      perm[b] = t;
      a++;
      b--;
    }
  }
  for (let i = 0; i < n; i++) iperm[perm[i]!] = i;
  return { perm, iperm };
}

export function spPermuteSym(A: SpMat, perm: Int32Array, iperm: Int32Array): SpMat {
  const t = trip();
  for (let i = 0; i < A.rows; i++) {
    const pi = iperm[i]!;
    for (let k = A.rowPtr[i]!; k < A.rowPtr[i + 1]!; k++) {
      tripAdd(t, pi, iperm[A.colInd[k]!]!, A.val[k]!);
    }
  }
  return spFromTriplets(A.rows, A.cols, t);
}

export { EPS, nrm2, dot, vec };
