import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { ident, mat, matAt, matSet, trip, tripAddSym, vec } from "./types.ts";
import { axpy, dot, nrm2 } from "./vec.ts";
import { gemm, gemmNaive, gemv, matFrob } from "./mat.ts";
import { lu, luSolve, solveSPD } from "./decomp.ts";
import { cg, pcg } from "./krylov.ts";
import { spFromTriplets, spmv } from "./sparse.ts";
import { skySolveSp } from "./skyline.ts";
import { meshRect, solveCantilever } from "./fea.ts";

describe("vec", () => {
  it("dot and axpy", () => {
    const n = 8;
    const x = new Float64Array(n).map((_, i) => i + 1);
    const y = new Float64Array(n).fill(2);
    assert.equal(dot(n, x, y), 2 * (n * (n + 1)) / 2);
    axpy(n, 1, x, y);
    assert.equal(y[0], 3);
  });
});

describe("gemm", () => {
  it("matches naive", () => {
    const n = 11;
    const A = mat(n, n);
    const B = mat(n, n);
    const C = mat(n, n);
    const D = mat(n, n);
    for (let i = 0; i < n * n; i++) {
      A.data[i] = ((i * 13) % 17) / 17;
      B.data[i] = ((i * 7) % 11) / 11;
    }
    gemm(1, A, B, 0, C);
    gemmNaive(n, n, n, 1, A.data, n, B.data, n, 0, D.data, n);
    let err = 0;
    for (let i = 0; i < n * n; i++) err = Math.max(err, Math.abs(C.data[i]! - D.data[i]!));
    assert.ok(err < 1e-12, `err=${err}`);
  });

  it("A * I = A", () => {
    const n = 9;
    const A = mat(n, n);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) matSet(A, i, j, i + 0.1 * j);
    const I = ident(n);
    const C = mat(n, n);
    gemm(1, A, I, 0, C);
    assert.ok(Math.abs(matFrob(C) - matFrob(A)) < 1e-12);
  });
});

describe("chol", () => {
  it("solves SPD tridiag", () => {
    const n = 12;
    const A = mat(n, n);
    const b = vec(n, 1);
    for (let i = 0; i < n; i++) {
      matSet(A, i, i, 4);
      if (i) {
        matSet(A, i, i - 1, -1);
        matSet(A, i - 1, i, -1);
      }
    }
    const Ac = mat(n, n);
    Ac.data.set(A.data);
    const x = vec(n);
    x.data.set(b.data);
    assert.equal(solveSPD(Ac, x), true);
    const r = vec(n);
    gemv("N", 1, A, x, 0, r);
    axpy(n, -1, b.data, r.data);
    assert.ok(nrm2(n, r.data) < 1e-10, `res=${nrm2(n, r.data)}`);
  });
});

describe("lu", () => {
  it("solves general system", () => {
    const n = 7;
    const A = mat(n, n);
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) matSet(A, i, j, ((i + 1) * (j + 3)) % 9);
      matSet(A, i, i, matAt(A, i, i) + 10);
    }
    const b = vec(n, 1);
    const Ac = mat(n, n);
    Ac.data.set(A.data);
    const ipiv = new Int32Array(n);
    assert.equal(lu(Ac, ipiv), true);
    const x = vec(n);
    x.data.set(b.data);
    luSolve(Ac, ipiv, x);
    const r = vec(n);
    gemv("N", 1, A, x, 0, r);
    axpy(n, -1, b.data, r.data);
    assert.ok(nrm2(n, r.data) < 1e-10);
  });
});

describe("sparse + krylov + skyline", () => {
  it("cg matches skyline on SPD", () => {
    const n = 20;
    const t = trip();
    for (let i = 0; i < n; i++) {
      tripAddSym(t, i, i, 0);
      t.vv[t.vv.length - 1] = 4;
      if (i) tripAddSym(t, i, i - 1, -1);
    }
    const Sp = spFromTriplets(n, n, t);
    const b = vec(n, 1);
    const x = vec(n);
    const info = cg(Sp, b, x, 1e-12, 200);
    assert.equal(info.converged, true);
    const y = vec(n);
    spmv(Sp, x, y);
    axpy(n, -1, b.data, y.data);
    assert.ok(nrm2(n, y.data) < 1e-9);

    const sky = skySolveSp(Sp, b, true);
    assert.equal(sky.ok, true);
    axpy(n, -1, x.data, sky.x.data);
    assert.ok(nrm2(n, sky.x.data) < 1e-8, `diff=${nrm2(n, sky.x.data)}`);
  });

  it("pcg jacobi converges", () => {
    const n = 16;
    const t = trip();
    for (let i = 0; i < n; i++) {
      t.ii.push(i); t.jj.push(i); t.vv.push(5);
      if (i) {
        t.ii.push(i); t.jj.push(i - 1); t.vv.push(-1);
        t.ii.push(i - 1); t.jj.push(i); t.vv.push(-1);
      }
    }
    const Sp = spFromTriplets(n, n, t);
    const b = vec(n, 1);
    const x = vec(n);
    const info = pcg(Sp, b, x, "jacobi", 1e-12, 200);
    assert.equal(info.converged, true);
  });
});

describe("fea cantilever", () => {
  it("tip deflection is within ~25% of beam theory", () => {
    const mesh = meshRect(16, 4, 10, 2, 210e9, 0.3, 0.1);
    const r = solveCantilever(mesh, -1e4, "skyline");
    assert.equal(r.info.converged, true, `res=${r.info.residual}`);
    assert.ok(Math.abs(r.ratio - 1) < 0.25, `ratio=${r.ratio} tip=${r.tipUy} beam=${r.analyticalUy}`);
    assert.ok(r.maxVm > 0);
  });

  it("skyline agrees with pcg", () => {
    const mesh = meshRect(8, 3, 10, 2, 210e9, 0.3, 0.1);
    const a = solveCantilever(mesh, -1e4, "pcg-jacobi");
    const b = solveCantilever(mesh, -1e4, "skyline");
    assert.equal(b.info.converged, true);
    assert.ok(Math.abs(a.tipUy - b.tipUy) / Math.abs(a.tipUy) < 1e-4, `${a.tipUy} vs ${b.tipUy}`);
  });
});
