/** Column-major double-precision types mirroring ferro64_types.pas */

export type Vec = { n: number; data: Float64Array };

export type Mat = {
  rows: number;
  cols: number;
  ld: number;
  data: Float64Array;
};

export type SpMat = {
  rows: number;
  cols: number;
  nnz: number;
  rowPtr: Int32Array;
  colInd: Int32Array;
  val: Float64Array;
};

export type Triplets = {
  ii: number[];
  jj: number[];
  vv: number[];
};

export type Skyline = {
  n: number;
  height: Int32Array;
  colPtr: Int32Array;
  val: Float64Array;
};

export type IterInfo = {
  iters: number;
  residual: number;
  converged: boolean;
  elapsedMs: number;
};

export const EPS = 2.220446049250313e-16;

export function vec(n: number, fill = 0): Vec {
  const data = new Float64Array(n);
  if (fill) data.fill(fill);
  return { n, data };
}

export function vecView(data: Float64Array, n = data.length): Vec {
  return { n, data };
}

export function mat(rows: number, cols: number, ld = rows): Mat {
  return { rows, cols, ld, data: new Float64Array(ld * cols) };
}

export function matAt(A: Mat, i: number, j: number): number {
  return A.data[i + j * A.ld]!;
}

export function matSet(A: Mat, i: number, j: number, v: number): void {
  A.data[i + j * A.ld] = v;
}

export function matCol(A: Mat, j: number): Float64Array {
  return A.data.subarray(j * A.ld, j * A.ld + A.rows);
}

export function trip(): Triplets {
  return { ii: [], jj: [], vv: [] };
}

export function tripAdd(t: Triplets, i: number, j: number, v: number): void {
  t.ii.push(i);
  t.jj.push(j);
  t.vv.push(v);
}

export function tripAddSym(t: Triplets, i: number, j: number, v: number): void {
  tripAdd(t, i, j, v);
  if (i !== j) tripAdd(t, j, i, v);
}

export function ident(n: number): Mat {
  const A = mat(n, n);
  for (let i = 0; i < n; i++) A.data[i + i * n] = 1;
  return A;
}

export function cloneMat(A: Mat): Mat {
  const B = mat(A.rows, A.cols);
  for (let j = 0; j < A.cols; j++) {
    B.data.set(A.data.subarray(j * A.ld, j * A.ld + A.rows), j * B.ld);
  }
  return B;
}

export function cloneVec(v: Vec): Vec {
  return { n: v.n, data: v.data.slice() };
}
