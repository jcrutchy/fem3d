import { mat } from "./types.ts";
import { gemm, gemmNaive, gemv } from "./mat.ts";
import { vec } from "./types.ts";
import { spFromDense, spmv } from "./sparse.ts";
import { chol } from "./decomp.ts";
import { cg } from "./krylov.ts";

export type BenchRow = {
  name: string;
  n: number;
  ms: number;
  gflops: number;
  note: string;
};

function timeIt(fn: () => void, minMs = 120): { ms: number; iters: number } {
  fn();
  const t0 = performance.now();
  let iters = 0;
  do {
    fn();
    iters++;
  } while (performance.now() - t0 < minMs);
  return { ms: (performance.now() - t0) / iters, iters };
}

function randMat(n: number, seed = 1): ReturnType<typeof mat> {
  const A = mat(n, n);
  let s = seed >>> 0;
  for (let i = 0; i < A.data.length; i++) {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    A.data[i] = (s / 0xffffffff) * 2 - 1;
  }
  return A;
}

export function runSuite(maxN = 192): BenchRow[] {
  const rows: BenchRow[] = [];
  const sizes = [32, 64, 96, 128].filter((n) => n <= maxN);
  if (maxN >= 160) sizes.push(Math.min(maxN, 192));

  for (const n of sizes) {
    const A = randMat(n, 1);
    const B = randMat(n, 2);
    const C = mat(n, n);
    const { ms } = timeIt(() => gemm(1, A, B, 0, C), n >= 128 ? 80 : 120);
    const gflops = (2 * n * n * n) / (ms * 1e6);
    rows.push({
      name: "GEMM blocked",
      n,
      ms,
      gflops,
      note: `${n}³  C(0,0)=${C.data[0]!.toExponential(3)}`,
    });
  }

  {
    const n = Math.min(64, maxN);
    const A = randMat(n, 3);
    const B = randMat(n, 4);
    const C = mat(n, n);
    const { ms } = timeIt(() => gemmNaive(n, n, n, 1, A.data, n, B.data, n, 0, C.data, n), 80);
    const gflops = (2 * n * n * n) / (ms * 1e6);
    rows.push({ name: "GEMM naive ijk", n, ms, gflops, note: "triple loop, same f64" });
  }

  {
    const n = Math.min(256, maxN * 2);
    const A = randMat(n, 5);
    const x = vec(n, 1);
    const y = vec(n);
    const { ms } = timeIt(() => gemv("N", 1, A, x, 0, y), 80);
    const gflops = (2 * n * n) / (ms * 1e6);
    rows.push({ name: "GEMV", n, ms, gflops, note: "column axpy" });
  }

  {
    const n = Math.min(96, maxN);
    const A = randMat(n, 7);
    for (let i = 0; i < n; i++) A.data[i + i * n]! += n;
    const { ms } = timeIt(() => {
      const B = mat(n, n);
      B.data.set(A.data);
      chol(B);
    }, 80);
    const gflops = (n * n * n) / 3 / (ms * 1e6);
    rows.push({ name: "Cholesky", n, ms, gflops, note: "in-place lower" });
  }

  {
    const n = Math.min(200, maxN * 2);
    const A = mat(n, n);
    for (let i = 0; i < n; i++) {
      A.data[i + i * n] = 4;
      if (i) {
        A.data[i + (i - 1) * n] = -1;
        A.data[i - 1 + i * n] = -1;
      }
    }
    const Sp = spFromDense(A, 0);
    const x = vec(n, 1);
    const y = vec(n);
    const { ms } = timeIt(() => spmv(Sp, x, y), 80);
    const gflops = (2 * Sp.nnz) / (ms * 1e6);
    rows.push({ name: "CSR SpMV", n, ms, gflops, note: `nnz=${Sp.nnz}` });

    const b = vec(n, 1);
    const z = vec(n);
    const t0 = performance.now();
    const info = cg(Sp, b, z, 1e-10, 2000);
    rows.push({
      name: "CG tridiag",
      n,
      ms: performance.now() - t0,
      gflops: 0,
      note: `${info.iters} iters  relres=${info.residual.toExponential(2)}`,
    });
  }

  return rows;
}
