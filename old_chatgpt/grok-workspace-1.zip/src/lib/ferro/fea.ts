import type { IterInfo, SpMat, Triplets, Vec } from "./types.ts";
import { trip, tripAdd, vec } from "./types.ts";
import { spFromTriplets } from "./sparse.ts";
import { pcg, type Precond } from "./krylov.ts";
import { skySolveSp } from "./skyline.ts";
import { chol, cholSolve } from "./decomp.ts";
import { mat, type Mat } from "./types.ts";
import { gemv } from "./mat.ts";

export type Node2 = { x: number; y: number };
export type Tri3 = [number, number, number];

export type FeaMesh2 = {
  nodes: Node2[];
  tris: Tri3[];
  E: number;
  nu: number;
  thick: number;
  Lx: number;
  Ly: number;
  nx: number;
  ny: number;
};

export type FeaResult = {
  u: Float64Array;
  vm: Float64Array;
  ndof: number;
  nnz: number;
  info: IterInfo;
  tipUy: number;
  analyticalUy: number;
  ratio: number;
  solver: string;
  profile?: number;
  maxVm: number;
};

export function meshRect(
  nx: number,
  ny: number,
  Lx: number,
  Ly: number,
  E: number,
  nu: number,
  thick: number,
): FeaMesh2 {
  nx = Math.max(1, nx | 0);
  ny = Math.max(1, ny | 0);
  const nxp = nx + 1;
  const nyp = ny + 1;
  const nodes: Node2[] = [];
  const dx = Lx / nx;
  const dy = Ly / ny;
  for (let j = 0; j < nyp; j++) {
    for (let i = 0; i < nxp; i++) nodes.push({ x: i * dx, y: j * dy });
  }
  const tris: Tri3[] = [];
  for (let j = 0; j < ny; j++) {
    for (let i = 0; i < nx; i++) {
      const n00 = i + j * nxp;
      const n10 = i + 1 + j * nxp;
      const n01 = i + (j + 1) * nxp;
      const n11 = i + 1 + (j + 1) * nxp;
      tris.push([n00, n10, n01]);
      tris.push([n10, n11, n01]);
    }
  }
  return { nodes, tris, E, nu, thick, Lx, Ly, nx, ny };
}

export function cstKe(
  n0: Node2,
  n1: Node2,
  n2: Node2,
  E: number,
  nu: number,
  thick: number,
): { Ke: Float64Array; Be: Float64Array; area: number } {
  const b0 = n1.y - n2.y;
  const b1 = n2.y - n0.y;
  const b2 = n0.y - n1.y;
  const c0 = n2.x - n1.x;
  const c1 = n0.x - n2.x;
  const c2 = n1.x - n0.x;
  const det = n0.x * (n1.y - n2.y) + n1.x * (n2.y - n0.y) + n2.x * (n0.y - n1.y);
  const area = 0.5 * det;
  const Ke = new Float64Array(36);
  const Be = new Float64Array(18);
  if (Math.abs(area) < 1e-18) return { Ke, Be, area };
  const s = 1 / det;
  Be[0] = b0 * s;
  Be[2] = b1 * s;
  Be[4] = b2 * s;
  Be[7] = c0 * s;
  Be[9] = c1 * s;
  Be[11] = c2 * s;
  Be[12] = c0 * s;
  Be[13] = b0 * s;
  Be[14] = c1 * s;
  Be[15] = b1 * s;
  Be[16] = c2 * s;
  Be[17] = b2 * s;
  const D00 = E / (1 - nu * nu);
  const D01 = D00 * nu;
  const D22 = E / (2 * (1 + nu));
  const DB = new Float64Array(18);
  for (let q = 0; q < 6; q++) {
    DB[q] = D00 * Be[q]! + D01 * Be[6 + q]!;
    DB[6 + q] = D01 * Be[q]! + D00 * Be[6 + q]!;
    DB[12 + q] = D22 * Be[12 + q]!;
  }
  const w = Math.abs(area) * thick;
  for (let i = 0; i < 6; i++) {
    for (let j = 0; j < 6; j++) {
      Ke[i * 6 + j] =
        (DB[i]! * Be[j]! + DB[6 + i]! * Be[6 + j]! + DB[12 + i]! * Be[12 + j]!) * w;
    }
  }
  return { Ke, Be, area };
}

export function assemble(mesh: FeaMesh2): { K: SpMat; f: Vec; fixed: Uint8Array } {
  const ndof = mesh.nodes.length * 2;
  const t: Triplets = trip();
  for (const tri of mesh.tris) {
    const { Ke } = cstKe(
      mesh.nodes[tri[0]]!,
      mesh.nodes[tri[1]]!,
      mesh.nodes[tri[2]]!,
      mesh.E,
      mesh.nu,
      mesh.thick,
    );
    const gdof = [
      2 * tri[0],
      2 * tri[0] + 1,
      2 * tri[1],
      2 * tri[1] + 1,
      2 * tri[2],
      2 * tri[2] + 1,
    ];
    for (let a = 0; a < 6; a++) {
      for (let b = 0; b < 6; b++) tripAdd(t, gdof[a]!, gdof[b]!, Ke[a * 6 + b]!);
    }
  }
  const K = spFromTriplets(ndof, ndof, t);
  const f = vec(ndof);
  const fixed = new Uint8Array(ndof);
  return { K, f, fixed };
}

export function applyTipLoad(mesh: FeaMesh2, f: Vec, Py: number): void {
  const xmax = mesh.Lx;
  const tips: number[] = [];
  mesh.nodes.forEach((nd, i) => {
    if (nd.x >= xmax - 1e-12) tips.push(i);
  });
  if (!tips.length) return;
  const share = Py / tips.length;
  for (const i of tips) f.data[2 * i + 1]! += share;
}

export function fixLeftEdge(mesh: FeaMesh2, fixed: Uint8Array): void {
  mesh.nodes.forEach((nd, i) => {
    if (nd.x <= 1e-14) {
      fixed[2 * i] = 1;
      fixed[2 * i + 1] = 1;
    }
  });
}

export function applyDirichlet(K: SpMat, f: Vec, fixed: Uint8Array): void {
  const n = K.rows;
  for (let i = 0; i < n; i++) {
    if (!fixed[i]) continue;
    let diag = 0;
    for (let k = K.rowPtr[i]!; k < K.rowPtr[i + 1]!; k++) {
      if (K.colInd[k] === i) diag = K.val[k]!;
    }
    if (!(Math.abs(diag) > 0)) diag = 1;
    for (let k = K.rowPtr[i]!; k < K.rowPtr[i + 1]!; k++) {
      K.val[k] = K.colInd[k] === i ? diag : 0;
    }
    f.data[i] = 0;
  }
  for (let i = 0; i < n; i++) {
    if (fixed[i]) continue;
    for (let k = K.rowPtr[i]!; k < K.rowPtr[i + 1]!; k++) {
      if (fixed[K.colInd[k]!]) K.val[k] = 0;
    }
  }
}

export function recoverVonMises(mesh: FeaMesh2, u: Float64Array): Float64Array {
  const vm = new Float64Array(mesh.tris.length);
  const D00 = mesh.E / (1 - mesh.nu * mesh.nu);
  const D01 = D00 * mesh.nu;
  const D22 = mesh.E / (2 * (1 + mesh.nu));
  mesh.tris.forEach((tri, e) => {
    const { Be } = cstKe(
      mesh.nodes[tri[0]]!,
      mesh.nodes[tri[1]]!,
      mesh.nodes[tri[2]]!,
      mesh.E,
      mesh.nu,
      mesh.thick,
    );
    const ue = [
      u[2 * tri[0]]!,
      u[2 * tri[0] + 1]!,
      u[2 * tri[1]]!,
      u[2 * tri[1] + 1]!,
      u[2 * tri[2]]!,
      u[2 * tri[2] + 1]!,
    ];
    let ex = 0, ey = 0, gxy = 0;
    for (let a = 0; a < 6; a++) {
      ex += Be[a]! * ue[a]!;
      ey += Be[6 + a]! * ue[a]!;
      gxy += Be[12 + a]! * ue[a]!;
    }
    const sx = D00 * ex + D01 * ey;
    const sy = D01 * ex + D00 * ey;
    const txy = D22 * gxy;
    vm[e] = Math.sqrt(sx * sx - sx * sy + sy * sy + 3 * txy * txy);
  });
  return vm;
}

export type FeaSolver = "pcg-jacobi" | "pcg-ic0" | "cg" | "skyline" | "dense-chol";

export function solveCantilever(
  mesh: FeaMesh2,
  Py: number,
  solver: FeaSolver,
): FeaResult {
  const { K, f, fixed } = assemble(mesh);
  applyTipLoad(mesh, f, Py);
  fixLeftEdge(mesh, fixed);
  applyDirichlet(K, f, fixed);
  const ndof = K.rows;
  let u = vec(ndof);
  let info: IterInfo = { iters: 0, residual: 0, converged: false, elapsedMs: 0 };
  let profile: number | undefined;
  const t0 = performance.now();

  if (solver === "skyline") {
    const r = skySolveSp(K, f, true);
    u = r.x;
    profile = r.profile;
    info = {
      iters: 1,
      residual: 0,
      converged: r.ok,
      elapsedMs: performance.now() - t0,
    };
  } else if (solver === "dense-chol") {
    const A: Mat = mat(ndof, ndof);
    for (let i = 0; i < ndof; i++) {
      for (let k = K.rowPtr[i]!; k < K.rowPtr[i + 1]!; k++) {
        A.data[i + K.colInd[k]! * ndof] = K.val[k]!;
      }
    }
    u.data.set(f.data);
    const ok = chol(A);
    if (ok) cholSolve(A, u);
    info = { iters: 1, residual: 0, converged: ok, elapsedMs: performance.now() - t0 };
  } else {
    const kind: Precond = solver === "pcg-jacobi" ? "jacobi" : solver === "pcg-ic0" ? "ic0" : "none";
    info = pcg(K, f, u, kind, 1e-8, Math.max(4000, ndof * 4));
  }

  let tipUy = 0;
  mesh.nodes.forEach((nd, i) => {
    if (nd.x >= mesh.Lx - 1e-12) {
      const uy = u.data[2 * i + 1]!;
      if (Math.abs(uy) > Math.abs(tipUy)) tipUy = uy;
    }
  });
  const Izz = (mesh.thick * mesh.Ly ** 3) / 12;
  const analyticalUy = (Py * mesh.Lx ** 3) / (3 * mesh.E * Izz);
  const vm = recoverVonMises(mesh, u.data);
  let maxVm = 0;
  for (let i = 0; i < vm.length; i++) if (vm[i]! > maxVm) maxVm = vm[i]!;

  return {
    u: u.data,
    vm,
    ndof,
    nnz: K.nnz,
    info,
    tipUy,
    analyticalUy,
    ratio: analyticalUy !== 0 ? tipUy / analyticalUy : 0,
    solver,
    profile,
    maxVm,
  };
}

export { gemv };
