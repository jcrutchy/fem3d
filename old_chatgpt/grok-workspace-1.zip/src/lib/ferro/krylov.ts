import type { IterInfo, SpMat, Vec } from "./types.ts";
import { EPS, vec } from "./types.ts";
import { axpy, dot, nrm2, scale } from "./vec.ts";
import { spDiag, spmv, spResidual } from "./sparse.ts";

export type Precond = "none" | "jacobi" | "ic0";

type IC0 = {
  n: number;
  rowPtr: Int32Array;
  colInd: Int32Array;
  val: Float64Array;
  ok: boolean;
};

function findVal(rowPtr: Int32Array, colInd: Int32Array, i: number, j: number): number {
  for (let k = rowPtr[i]!; k < rowPtr[i + 1]!; k++) if (colInd[k] === j) return k;
  return -1;
}

function buildIC0(A: SpMat): IC0 {
  const n = A.rows;
  const rowPtr = A.rowPtr.slice();
  const colInd = A.colInd.slice();
  const val = A.val.slice();
  const M: IC0 = { n, rowPtr, colInd, val, ok: true };
  for (let i = 0; i < n; i++) {
    for (let p = rowPtr[i]!; p < rowPtr[i + 1]!; p++) {
      const j = colInd[p]!;
      if (j > i) continue;
      let s = val[p]!;
      for (let q = rowPtr[i]!; q < rowPtr[i + 1]!; q++) {
        const k = colInd[q]!;
        if (k >= j || k >= i) continue;
        const pj = findVal(rowPtr, colInd, j, k);
        if (pj >= 0) s -= val[q]! * val[pj]!;
      }
      if (j < i) {
        const r = findVal(rowPtr, colInd, j, j);
        if (r < 0) {
          M.ok = false;
          return M;
        }
        const Lii = val[r]!;
        if (Math.abs(Lii) < EPS) {
          M.ok = false;
          return M;
        }
        val[p] = s / Lii;
      } else {
        if (!(s > 0)) {
          M.ok = false;
          return M;
        }
        val[p] = Math.sqrt(s);
      }
    }
  }
  return M;
}

function ic0Apply(M: IC0, r: Vec, z: Vec): void {
  const n = M.n;
  const y = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let s = r.data[i]!;
    let diag = 1;
    for (let p = M.rowPtr[i]!; p < M.rowPtr[i + 1]!; p++) {
      const j = M.colInd[p]!;
      if (j < i) s -= M.val[p]! * y[j]!;
      else if (j === i) diag = M.val[p]!;
    }
    if (Math.abs(diag) < EPS) diag = 1;
    y[i] = s / diag;
  }
  z.data.set(y);
  for (let i = n - 1; i >= 0; i--) {
    let diag = 1;
    for (let p = M.rowPtr[i]!; p < M.rowPtr[i + 1]!; p++) {
      if (M.colInd[p] === i) diag = M.val[p]!;
    }
    if (Math.abs(diag) < EPS) diag = 1;
    z.data[i]! /= diag;
    const zi = z.data[i]!;
    for (let p = M.rowPtr[i]!; p < M.rowPtr[i + 1]!; p++) {
      const j = M.colInd[p]!;
      if (j < i) z.data[j]! -= M.val[p]! * zi;
    }
  }
}

function jacobiApply(d: Vec, r: Vec, z: Vec): void {
  for (let i = 0; i < d.n; i++) {
    const di = d.data[i]!;
    z.data[i] = Math.abs(di) > EPS ? r.data[i]! / di : r.data[i]!;
  }
}

export function pcg(
  A: SpMat,
  b: Vec,
  x: Vec,
  kind: Precond = "none",
  tol = 1e-10,
  maxIter = 2000,
): IterInfo {
  const t0 = performance.now();
  const n = b.n;
  const r = vec(n);
  const p = vec(n);
  const Ap = vec(n);
  const z = vec(n);
  const d = vec(n);
  let M: IC0 | null = null;
  if (kind === "jacobi") spDiag(A, d);
  if (kind === "ic0") M = buildIC0(A);

  const apply = () => {
    if (kind === "jacobi") jacobiApply(d, r, z);
    else if (kind === "ic0" && M?.ok) ic0Apply(M, r, z);
    else z.data.set(r.data);
  };

  spResidual(A, x, b, r);
  let bnrm = nrm2(n, b.data);
  if (bnrm === 0) bnrm = 1;
  apply();
  p.data.set(z.data);
  let rz = dot(n, r.data, z.data);
  const rz0 = rz;
  let iters = 0;
  let residual = nrm2(n, r.data) / bnrm;
  let converged = residual <= tol;

  while (!converged && iters < maxIter) {
    iters++;
    spmv(A, p, Ap);
    let alpha = dot(n, p.data, Ap.data);
    if (Math.abs(alpha) < EPS * Math.abs(rz0 || 1)) break;
    alpha = rz / alpha;
    axpy(n, alpha, p.data, x.data);
    axpy(n, -alpha, Ap.data, r.data);
    residual = nrm2(n, r.data) / bnrm;
    if (residual <= tol) {
      converged = true;
      break;
    }
    apply();
    const rzOld = rz;
    rz = dot(n, r.data, z.data);
    if (Math.abs(rzOld) < EPS * Math.abs(rz0 || 1)) break;
    const beta = rz / rzOld;
    scale(n, beta, p.data);
    axpy(n, 1, z.data, p.data);
  }
  return { iters, residual, converged, elapsedMs: performance.now() - t0 };
}

export function cg(A: SpMat, b: Vec, x: Vec, tol = 1e-10, maxIter = 2000): IterInfo {
  return pcg(A, b, x, "none", tol, maxIter);
}

export function gmres(
  A: SpMat,
  b: Vec,
  x: Vec,
  restart = 30,
  tol = 1e-10,
  maxIter = 2000,
): IterInfo {
  const t0 = performance.now();
  const n = b.n;
  const m = Math.max(4, Math.min(50, restart));
  const V = new Float64Array(n * (m + 1));
  const H = Array.from({ length: m + 1 }, () => new Float64Array(m));
  const cs = new Float64Array(m);
  const sn = new Float64Array(m);
  const g = new Float64Array(m + 1);
  const y = new Float64Array(m);
  const w = vec(n);
  const resid = vec(n);
  let bnrm = nrm2(n, b.data);
  if (bnrm === 0) bnrm = 1;
  let iters = 0;
  let residual = 1;
  let converged = false;

  outer: while (iters < maxIter) {
    spResidual(A, x, b, resid);
    let rnrm = nrm2(n, resid.data);
    residual = rnrm / bnrm;
    if (residual <= tol) {
      converged = true;
      break;
    }
    scale(n, 1 / rnrm, resid.data);
    V.set(resid.data.subarray(0, n), 0);
    g.fill(0);
    g[0] = rnrm;
    let jend = -1;
    for (let j = 0; j < m; j++) {
      iters++;
      w.data.set(V.subarray(j * n, j * n + n));
      spmv(A, w, w);
      for (let i = 0; i <= j; i++) {
        H[i]![j] = dot(n, V.subarray(i * n, i * n + n), w.data);
        axpy(n, -H[i]![j]!, V.subarray(i * n, i * n + n), w.data);
      }
      H[j + 1]![j] = nrm2(n, w.data);
      if (H[j + 1]![j]! > EPS) {
        scale(n, 1 / H[j + 1]![j]!, w.data);
        V.set(w.data, (j + 1) * n);
      }
      for (let i = 0; i < j; i++) {
        const tmp = cs[i]! * H[i]![j]! + sn[i]! * H[i + 1]![j]!;
        H[i + 1]![j] = -sn[i]! * H[i]![j]! + cs[i]! * H[i + 1]![j]!;
        H[i]![j] = tmp;
      }
      const hii = H[j]![j]!;
      const hij = H[j + 1]![j]!;
      let tmp = Math.hypot(hii, hij) || EPS;
      cs[j] = hii / tmp;
      sn[j] = hij / tmp;
      H[j]![j] = tmp;
      H[j + 1]![j] = 0;
      tmp = cs[j]! * g[j]!;
      g[j + 1] = -sn[j]! * g[j]!;
      g[j] = tmp;
      residual = Math.abs(g[j + 1]!) / bnrm;
      jend = j;
      if (residual <= tol || iters >= maxIter) break;
    }
    if (jend < 0) break;
    for (let i = 0; i <= jend; i++) y[i] = g[i]!;
    for (let i = jend; i >= 0; i--) {
      for (let k = i + 1; k <= jend; k++) y[i]! -= H[i]![k]! * y[k]!;
      y[i] = Math.abs(H[i]![i]!) < EPS ? 0 : y[i]! / H[i]![i]!;
    }
    for (let i = 0; i <= jend; i++) axpy(n, y[i]!, V.subarray(i * n, i * n + n), x.data);
    if (residual <= tol) {
      converged = true;
      break outer;
    }
  }
  return { iters, residual, converged, elapsedMs: performance.now() - t0 };
}

export function bicgstab(A: SpMat, b: Vec, x: Vec, tol = 1e-10, maxIter = 2000): IterInfo {
  const t0 = performance.now();
  const n = b.n;
  const r = vec(n);
  const rhat = vec(n);
  const p = vec(n);
  const v = vec(n);
  const s = vec(n);
  const t = vec(n);
  spResidual(A, x, b, r);
  rhat.data.set(r.data);
  p.data.set(r.data);
  let rho = dot(n, rhat.data, r.data);
  let bnrm = nrm2(n, b.data);
  if (bnrm === 0) bnrm = 1;
  let iters = 0;
  let residual = nrm2(n, r.data) / bnrm;
  let converged = residual <= tol;
  while (!converged && iters < maxIter) {
    iters++;
    spmv(A, p, v);
    let alpha = dot(n, rhat.data, v.data);
    if (Math.abs(alpha) < EPS) break;
    alpha = rho / alpha;
    s.data.set(r.data);
    axpy(n, -alpha, v.data, s.data);
    if (nrm2(n, s.data) / bnrm <= tol) {
      axpy(n, alpha, p.data, x.data);
      residual = nrm2(n, s.data) / bnrm;
      converged = true;
      break;
    }
    spmv(A, s, t);
    let omega = dot(n, t.data, t.data);
    if (Math.abs(omega) < EPS) break;
    omega = dot(n, t.data, s.data) / omega;
    axpy(n, alpha, p.data, x.data);
    axpy(n, omega, s.data, x.data);
    r.data.set(s.data);
    axpy(n, -omega, t.data, r.data);
    residual = nrm2(n, r.data) / bnrm;
    if (residual <= tol) {
      converged = true;
      break;
    }
    const rhoOld = rho;
    rho = dot(n, rhat.data, r.data);
    if (Math.abs(rhoOld * omega) < EPS) break;
    const beta = (rho / rhoOld) * (alpha / omega);
    axpy(n, -omega, v.data, p.data);
    scale(n, beta, p.data);
    axpy(n, 1, r.data, p.data);
  }
  return { iters, residual, converged, elapsedMs: performance.now() - t0 };
}
