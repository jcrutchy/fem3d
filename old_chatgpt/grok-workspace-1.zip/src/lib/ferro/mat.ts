import type { Mat, Vec } from "./types.ts";
import { axpy, copy, dot, nrm2, scale } from "./vec.ts";

export type MatOp = "N" | "T";

export function gemv(
  trans: MatOp,
  alpha: number,
  A: Mat,
  x: Vec,
  beta: number,
  y: Vec,
): void {
  scale(y.n, beta, y.data);
  if (alpha === 0) return;
  if (trans === "N") {
    const cols = Math.min(A.cols, x.n);
    for (let j = 0; j < cols; j++) {
      axpy(A.rows, alpha * x.data[j]!, A.data, y.data, j * A.ld, 0);
    }
  } else {
    const cols = Math.min(A.cols, y.n);
    for (let j = 0; j < cols; j++) {
      y.data[j]! += alpha * dot(A.rows, A.data, x.data, j * A.ld, 0);
    }
  }
}

/** C := alpha A B + beta C, all column-major, no-transpose. Blocked rank-1. */
export function gemmNN(
  m: number,
  n: number,
  k: number,
  alpha: number,
  A: Float64Array,
  lda: number,
  B: Float64Array,
  ldb: number,
  beta: number,
  C: Float64Array,
  ldc: number,
): void {
  if (beta === 0) {
    for (let j = 0; j < n; j++) C.fill(0, j * ldc, j * ldc + m);
  } else if (beta !== 1) {
    for (let j = 0; j < n; j++) {
      const co = j * ldc;
      for (let i = 0; i < m; i++) C[co + i]! *= beta;
    }
  }
  if (alpha === 0) return;

  const KC = 96;
  for (let p0 = 0; p0 < k; p0 += KC) {
    const p1 = Math.min(k, p0 + KC);
    for (let j = 0; j < n; j++) {
      const co = j * ldc;
      const bo = j * ldb;
      for (let p = p0; p < p1; p++) {
        const b = alpha * B[bo + p]!;
        if (b === 0) continue;
        const ao = p * lda;
        let i = 0;
        const m4 = m & ~3;
        for (; i < m4; i += 4) {
          C[co + i]! += A[ao + i]! * b;
          C[co + i + 1]! += A[ao + i + 1]! * b;
          C[co + i + 2]! += A[ao + i + 2]! * b;
          C[co + i + 3]! += A[ao + i + 3]! * b;
        }
        for (; i < m; i++) C[co + i]! += A[ao + i]! * b;
      }
    }
  }
}

export function gemmNaive(
  m: number,
  n: number,
  k: number,
  alpha: number,
  A: Float64Array,
  lda: number,
  B: Float64Array,
  ldb: number,
  beta: number,
  C: Float64Array,
  ldc: number,
): void {
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < m; i++) {
      let s = 0;
      for (let p = 0; p < k; p++) s += A[i + p * lda]! * B[p + j * ldb]!;
      const idx = i + j * ldc;
      C[idx] = beta === 0 ? alpha * s : alpha * s + beta * C[idx]!;
    }
  }
}

export function gemm(alpha: number, A: Mat, B: Mat, beta: number, C: Mat): void {
  gemmNN(C.rows, C.cols, A.cols, alpha, A.data, A.ld, B.data, B.ld, beta, C.data, C.ld);
}

export function matScale(alpha: number, A: Mat): void {
  for (let j = 0; j < A.cols; j++) scale(A.rows, alpha, A.data, j * A.ld);
}

export function matCopy(A: Mat, B: Mat): void {
  const n = Math.min(A.rows, B.rows);
  for (let j = 0; j < Math.min(A.cols, B.cols); j++) {
    copy(n, A.data, B.data, j * A.ld, j * B.ld);
  }
}

export function matFrob(A: Mat): number {
  let s = 0;
  for (let j = 0; j < A.cols; j++) s += dot(A.rows, A.data, A.data, j * A.ld, j * A.ld);
  return Math.sqrt(s);
}

export function matFill(A: Mat, a: number): void {
  for (let j = 0; j < A.cols; j++) A.data.fill(a, j * A.ld, j * A.ld + A.rows);
}

export { nrm2 };
