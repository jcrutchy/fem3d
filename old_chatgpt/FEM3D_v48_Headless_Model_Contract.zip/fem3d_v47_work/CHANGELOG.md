# Changelog

## v0.48

- Restored/retained Lazarus `.lfm` resources from v0.47.
- Corrected native model analysis-case loading so `Name`, `Type`, `LoadCase` and `ResultID` are actually persisted/restored.
- Added support for `[SETTINGS]` analysis sections during model loading.
- Accepted `LINEAR_STATIC` / `LINEAR-STATIC` style analysis type spellings.
- Accepted `ReferenceDenseLDLT` as an alias for the reference dense LDL^T solver name.
- Added `Tolerance=` compatibility for linear-static model files.
- Removed duplicate inactive solver source tree under `solver/src`.
- Added GUI-independent `FEM3D_CLI.exe` orchestration client.
- Added headless `validate`, `info`, `results` and `solve` commands.
- Added headless workflow documentation.
