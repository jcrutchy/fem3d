unit FEMBeamMesher;
{$mode objfpc}{$H+}

interface

uses SysUtils, Math, FEMTypes, FEMModel, FEMModelEditor;

type
  TBeamMeshOptions = record
    MaximumElementLength: Double;
  end;

  TBeamMesher = class
  public
    class function MeshBeamByMaximumLength(Model: TFEMModel; Editor: TModelEditor;
      ElementID: Integer; const Options: TBeamMeshOptions;
      out Segments,CreatedNodes,CreatedElements: Integer): Boolean;
  end;

implementation

class function TBeamMesher.MeshBeamByMaximumLength(Model: TFEMModel; Editor: TModelEditor;
  ElementID: Integer; const Options: TBeamMeshOptions;
  out Segments,CreatedNodes,CreatedElements: Integer): Boolean;
var I,A,B: Integer; L: Double;
begin
  Result:=False; Segments:=0; CreatedNodes:=0; CreatedElements:=0;
  if (Model=nil) or (Editor=nil) or (Options.MaximumElementLength<=0) then Exit;
  I:=-1;
  for A:=0 to High(Model.Elements) do if Model.Elements[A].ID=ElementID then begin I:=A; Break; end;
  if I<0 then Exit;
  if (Length(Model.Elements[I].NodeIDs)<>2) or
     (not SameText(Model.Elements[I].Kind,'BEAM3D')) then Exit;
  A:=Model.FindNode(Model.Elements[I].NodeIDs[0]);
  B:=Model.FindNode(Model.Elements[I].NodeIDs[1]);
  if (A<0) or (B<0) then Exit;
  L:=VNorm(VSub(Model.Nodes[B].Position,Model.Nodes[A].Position));
  if L<=1e-12 then Exit;
  Segments:=Max(1,Ceil(L/Options.MaximumElementLength));
  if Segments=1 then begin CreatedElements:=1; Result:=True; Exit; end;
  Result:=Editor.SubdivideElement(ElementID,Segments,CreatedNodes,CreatedElements);
end;

end.
